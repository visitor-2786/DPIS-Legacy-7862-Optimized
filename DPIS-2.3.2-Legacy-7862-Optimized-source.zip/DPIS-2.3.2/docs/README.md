# 文档入口

这里用于快速找到 DPIS 仍在维护的文档。根目录 `README.md` 面向普通用户；这里负责把用户入口、开发入口和历史资料分开。

## 普通用户

- [中文 README](../README.md)：安装前快速了解 DPIS 能做什么、怎么开始使用。
- [English README](./README.en.md)：English introduction and quick start.

## 开发者

- [AGENTS.md](../AGENTS.md)：项目结构、构建测试命令和协作约定。
- [project-visual-map-2026-04-19.md](./archive/plans/project-visual-map-2026-04-19.md)：项目结构和主要修改落点速览（已归档）。

## 开发与排障

- [modern-runtime-resync.md](./modern-runtime-resync.md)：Modern/libxposed 视口与 runtime 路线记录。
- [legacy-runtime-resync.md](./legacy-runtime-resync.md)：Legacy/传统 Xposed 兼容路线记录。
- [lsposed-diagnostics.md](./lsposed-diagnostics.md)：LSPosed 模块日志拉取、过滤和判断方式。
- [font-routing.md](./font-routing.md)：字体模式、自定义 Hook 链路和内部调度边界。
- [java-toolchain-policy.md](./java-toolchain-policy.md)：JDK、Java 兼容级别和 Android API 使用边界。
- [CONTEXT.md](../CONTEXT.md)：领域语言。外观（运行时配色、Wear 映射、token 深度）在 **Appearance**。
- [ui-guidelines.md](./ui-guidelines.md)：Compose 优先的 UI 修改约定。XML 样板是遗留，不是默认落点。
- [architecture-ownership.md](./architecture-ownership.md)：Activity / `ui/` / policy 所有权约束，以及后续 host 迁移顺序。
- [package-classification-plan.md](./package-classification-plan.md)：按特征增量迁包的账本，不是一次做完的迁移计划。
- [diagnostic-performance-architecture.md](./diagnostic-performance-architecture.md)：反馈诊断证据模型。
- [feedback-diagnostic-perfetto.md](./feedback-diagnostic-perfetto.md)：诊断 ZIP 里 Perfetto trace 的分析用法。
- [agents/](./agents/)：Agent 协作配置、issue tracker 信息和运行时排查流程。
- [sonarqube.md](./sonarqube.md)：CI 扫描配置，以及用 SonarQube MCP 读质量门和覆盖率。

## 计划与历史记录

已完成的执行计划和设计在 [archive/](./archive/)。近期归档：

- [compose-workspace-migration.md](./archive/specs/compose-workspace-migration.md)
- [system-font-scale-tool-ui.md](./archive/specs/system-font-scale-tool-ui.md)
- [2026-09-12-page-chrome-contract.md](./archive/specs/2026-09-12-page-chrome-contract.md)
- [2026-09-08-app-config-prefill-session.md](./archive/plans/2026-09-08-app-config-prefill-session.md)
- [2026-09-08-app-config-prefill-session-design.md](./archive/specs/2026-09-08-app-config-prefill-session-design.md)
- [2026-09-05-compose-presentation-cleanup.md](./archive/plans/2026-09-05-compose-presentation-cleanup.md)

## 归档

- [archive/README.md](./archive/README.md)
- [archive/](./archive/)
- [archive/reports/docs-curation-2026-04-20.md](./archive/reports/docs-curation-2026-04-20.md)
- [archive/reports/docs-curation-2026-04-17.md](./archive/reports/docs-curation-2026-04-17.md)

## 维护约定

- 修改视口/runtime hook 路线前，先读对应的 Modern 或 Legacy 路线文档；触碰共享代码时两个都读。
- 新路线探索、失败实验、未采用方案和关键运行证据应记录到对应路线文档。
- 新文档先判断是否仍然有效；已经过期或只用于历史追踪的内容放入 `docs/archive/`。
