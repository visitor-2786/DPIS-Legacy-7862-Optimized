# Legacy Runtime Resync

This is the living tracker for the Legacy viewport/runtime investigation.

## Living Document Rules

- Read this document before adding, changing, or removing any Legacy
  viewport/runtime route. If the change touches shared runtime code under
  `app/src/main/java/com/dpis/module/`, also read
  `docs/modern-runtime-resync.md`.
- For WeChat-specific investigation notes and the native target-field route,
  see `docs/private/` (not committed).
- For LSPosed log diagnostics, see `docs/lsposed-diagnostics.md`.
- Record every new route exploration, route detail adjustment, failed attempt,
  unused path, and important runtime finding here. Treat experiments as
  accumulated evidence, not disposable notes.
- Do not delete historical route records unless they are duplicated or
  misleading. Prefer marking them `active`, `inactive`, `superseded`,
  `rejected`, or `unknown`, with a short reason and the evidence that changed
  the decision.
- Keep the tree and ledger aligned: when a route moves between active and
  inactive use, update both the route tree and the experiment ledger.

## Route Map

## Window Semantics

The shared `viewport/window` layer keeps four meanings separate:

- capability: whether a vendor/framework exposes flexible-window support;
- policy: whether an app or ratio is allowed by that framework;
- state: whether the current task is fullscreen, freeform, split-screen, or
  unknown;
- geometry: the current bounds, app bounds, and maximum bounds.

`WindowScopeResolver` answers only the current state and carries evidence,
confidence, geometry, and capability facts. A vendor policy method such as
ColorOS `FlexibleWindowUtils.isSupportFlexibleWindow` must not be treated as
proof that the current task is a small window. A future system_server adapter
may supply task state and geometry through this contract without making common
app-process code depend on vendor controller classes.

```text
Viewport mode
  auto
    -> system hooks enabled  => system
    -> system hooks unavailable or ineffective => compat

  system
    -> system_server mutation route
    -> app-process Resources bridge remains installed for resource sync/fallback
    -> app-process Display / WindowMetrics supplement is skipped by design

  compat
    -> app-process resource/display/window route
    -> explicit app-process route when selected

Font mode
  system
    -> internal system_server_font domain
    -> legacy system_server launch-activity-item writes
       Configuration.fontScale only
    -> internal app-process semantic supplements:
       activity_thread_font, resources_font, webview_text_zoom

  compat
    -> app-process field-rewrite route
    -> automatic defaults exclude resources_font
    -> resources_font remains manually selectable for read-path value rewrite
    -> custom hook-chain UI controls this mode only
```

## Preference Boundary (LSPosed 2.3)

Status: active compatibility boundary.

Legacy remains the only hook family that owns the classic
`XSharedPreferencesAdapter`. It is implemented in the Legacy source set as a
Kotlin snapshot adapter and is used only when the runtime-property bridge or a
Modern remote-preferences service is not available. The Legacy APK retains the
classic Xposed metadata for hosts that still expose that API. Do not move this
adapter back into shared code or add it to Modern fallback paths: LSPosed 2.3
may remove the class and Modern must remain remote-preferences-only.

## Feedback Diagnostic Runtime Timeline

Status: active first pass.

Feedback diagnostic sessions merge selected centralized `DpisLog` messages,
LSPosed lines parsed inside the diagnostic time window, and an experimental
append-only runtime transport into `diagnostic.txt`. Legacy routes are observed
through the same centralized logging boundary rather than new per-hook behavior.
Raw LSPosed evidence remains in `lsposed-log.txt`; structured parsed events are
marked `source=lsposed-log`.

The transport path is intentionally small: root prepares a marker and event file
under `/data/local/tmp/dpis-feedback-diagnostic`, then hook processes attempt to
append events when the marker is readable. Android sandbox or SELinux failures
are silent in hooks and exported as `source=runtime-transport` notes. This is a
first-pass feasibility probe, not a replacement for LSPosed diagnostics.

Runtime hotpath fallback currently covers the shared font field-rewrite paths
that also serve Legacy app-process hooks: TextAppearance, TextView `setTextSize`
SP/absolute rewrites, TextView current-px attach/setText reinforcement,
TextView span rewrite, Paint/TextPaint fallback, Android WebView textZoom, and
X5 WebView textZoom. The events are diagnostic-only and gated by the active
feedback-diagnostic marker.

As of 2026-08-13, diagnostic ZIPs include `timeline.tsv` and
`module-effects.tsv`. `module-effects.tsv` emits a `source=diagnostic-plan`
zero row for any selected route that has no observed effect in the session
window. Treat this as a route-evidence gap, not as evidence that the Legacy route
executed or mutated the target process.

As of 2026-09-21, the shared exporter treats structured hot-path events as
observed modules, not only ProcessPerformance aggregates. Shared WeChat DPI
`mutation_applied` evidence must suppress the WeChat “no route effect”
filler even when the pack’s aggregates are font-only. Shared
`textview_current_px_fallback` details now include `in=`/`out=`. Pack
analysis lives in `tools/analyze_diagnostic_pack.py`.

As of 2026-08-14, the shared Modern `system_server` installer publishes
target-package-scoped, rate-limited `runtime-transport` events for its
viewport mutation and selected skip paths. Legacy does not install that shared
viewport installer, so its own launch-only font route is not represented by
these events. Transport absence remains an evidence gap, not proof that a
system-side route did not execute.

As of 2026-08-14, Legacy and shared app-process hotpath diagnostics enqueue
transport and LSPosed bridge records away from the hook callback thread. The
transport batches short writes and the DPIS stop path flushes its local queue;
the bridge queue is bounded so diagnostic capture cannot grow without limit.
Queue overflow is an evidence-completeness limitation, not evidence that the
Legacy route did not execute.

As of 2026-08-15, shared compat field-rewrite setters use a synchronous
`FontMutationScheduler` decision boundary. Paint/TextPaint fallback keeps an
already-target-sized object when the same recorded base size repeats, avoiding
redundant native setters. Legacy keeps required synchronous mutations and still
re-arbitrates after external drift, factor changes, or a new base size.
The diagnostic aggregate exports this outcome as `kept`, separately from
ordinary skipped callbacks.

As of 2026-09-21, the shared scheduler adds nested `PASS_THROUGH` and per-object
Paint slots. Legacy uses the same `runtime.font` installers: identity-bound
already-applied marks, in-flight `withMutation`, and layout-stack stronger
ownership. A later independent `28.2` still rewrites. Nested Paint is `kept`,
not a second `applied`. Do not treat `28.2 -> 26.508` as a WeChat-only branch.

The shared app-process font route implementation now lives under
`runtime.font`. Legacy flavor entry points still call the same install/reset
protocols; the move only classifies ActivityThread, Resources font scheduling,
TextView/Paint field rewrite, WebView, typeface replacement, Flutter, and
diagnostic font routes under their runtime owner package.
The shared app-process viewport/window route implementation now lives under
`runtime.appprocess`. Flavor entry points still call the same
install/reset/apply protocols; the move is package classification only and does
not change route selection, mutation policy, or evidence semantics.

- 2026-07-12: Legacy imported typeface diagnostics now match Modern: Provider
  or fallback source, hook installation, first replacement hit per source, and
  load failure are emitted as stable `typeface` timeline stages. This is
  observational only and preserves Legacy hook behavior.

As of 2026-06-22, the Legacy WeChat DPI route participates in feedback
diagnostics as `route=wechat_dpi` for WeChat targets. A saved WeChat DPI config
makes callback and mutation evidence expected; without that config, callback or
mutation hits are unexpected route activity. The legacy load-package route and
DisplayMetrics hook emit structured evidence for route entry, install attempt,
hook ready, callback, applied mutation, and skipped or failed locator paths.

## Full Tree

```text
DPIS viewport target package
  |
  +-- flavor boundary
  |     |
  |     +-- modern
  |     |     |
  |     |     +-- entry: app/src/modern/java/com/dpis/module/ModuleMain.java
  |     |     +-- system_server route:
  |     |     |     runtime.systemserver.SystemServerDisplayEnvironmentInstaller
  |     |     +-- app-process route:
  |     |           runtime.appprocess.AppProcessHookInstaller
  |     |           runtime.appprocess.ResourcesManagerHookInstaller
  |     |           runtime.appprocess.ResourcesImplHookInstaller
  |     |           runtime.appprocess.ResourcesReadHookInstaller
  |     |           runtime.appprocess.DisplayHookInstaller / runtime.appprocess.WindowMetricsHookInstaller
  |     |
  |     +-- legacy
  |           |
  |           +-- entry: app/src/legacy/java/com/dpis/module/LegacyModuleHook.java
  |           +-- system_server route:
  |           |     LegacySystemServerHookInstaller
  |           |       |
  |           |       +-- launch-activity-item
  |           |       |     status: applies FONT_SCALE only for system font mode
  |           |       |
  |           |       +-- rust-process
  |           |       |     status: HyperOS native font environment route;
  |           |       |             unrelated to viewport
  |           |
  |           +-- app-process route:
  |                 |
  |                 +-- ResourcesImpl.updateConfiguration
  |                 |     writes Configuration / DisplayMetrics
  |                 |
  |                 +-- ResourcesManager.applyConfigurationToResources
  |                 |     writes process resource configuration
  |                 |
  |                 +-- ResourcesManager.updateResourcesForActivity
  |                 |     status: active for navigation refresh
  |                 |
  |                 +-- ResourcesManager.createResourcesImpl(ResourcesKey)
  |                 |     status: active for key override fill
  |                 |
  |                 +-- Resources.getConfiguration / getDisplayMetrics / getSystem
  |                 |     read-time compensation
  |                 |
  |                 +-- Display.getMetrics / getRealMetrics / getSize / getRealSize / getDisplayInfo
  |                 |     app-process display supplement
  |                 |
  |                 +-- WindowMetrics.getBounds
  |                 |     app-process window supplement
  |                 |
  |                 +-- ActivityThread.handleBindApplication
  |                 |     system-font semantic bind-time supplement
  |                 |
  |                 +-- Resources / WebView semantic font routes
  |                 |     resources_font and webview_text_zoom for system font mode
  |                 |
  |                 +-- TextView / Paint / WebView field-rewrite routes
  |                 |     custom hook-chain UI controls these in compat font mode;
  |                 |     resources_font is manual, not automatic
  |                 |
  |                 +-- FlutterJNI.setViewportMetrics
  |                 |     status: active for Flutter/mixed shells
  |                 |     aligns Flutter devicePixelRatio to DPIS target density
  |                 |
  |                 +-- WebView / XWeb / TBS layout JS supplement
  |                       status: per-app configurable; disabled for unstable targets
  |
  +-- requested mode
        |
        +-- system
        |     +-- EffectiveModeResolver => system
        |     +-- system_server hooks required
        |     +-- app-process Resources bridge remains installed
        |     +-- app-process Display / WindowMetrics supplement skipped
        |
        +-- compat
        |     +-- EffectiveModeResolver => compat
        |     +-- app-process hooks required
        |
        +-- auto
              +-- system hooks enabled
              |     +-- EffectiveModeResolver => system
              +-- system hooks disabled
                    +-- EffectiveModeResolver => compat
```

## Current Route Decision

The legacy absolute-width viewport route is this coverage model when the
resolved route is `system` or `compat`:

```text
legacy auto/system absolute viewport
  |
  +-- app-process Resources bridge
  |     -> covers Java resource reads and ResourcesKey creation during navigation
  |
  +-- app-process Display / WindowMetrics supplements
  |     -> covers app-local display metric reads when resolved mode is compat;
  |        skipped when resolved mode is system
  |
  +-- app-process FlutterJNI viewport metrics bridge
        -> covers Flutter/mixed shells that consume engine viewport DPR
```

Legacy main-process auto treats any enabled viewport target as an app-process
compat projection route. This keeps relative-scale targets from falling back to
off when system hooks are unavailable.

legacy does not currently install the shared modern
`runtime.systemserver.SystemServerDisplayEnvironmentInstaller`, so `config-dispatch` and
`display-manager-info` are not active legacy system_server routes. The
legacy system_server installer keeps only the launch-time Configuration
route and the HyperOS Rust process environment route.

Per-app guards (splash startup filter, Display/WindowMetrics disable,
Flutter activity scope) are configured independently per target package.
See `docs/private/` for app-specific investigation notes.

## System Font Route Decision

```text
legacy system font mode
  |
  +-- system_server launch-activity-item
  |     -> writes Configuration.fontScale only at launch time
  |
  +-- app-process ActivityThread bind supplement
  |     -> rewrites AppBindData.config.fontScale before app bind proceeds
  |
  +-- app-process Resources / WebView semantic supplements
  |     -> preserve fontScale reads and WebView text zoom without TextView field rewrite
  |
  +-- optional Flutter/HyperOS native supplements
        -> remain package/config gated
```

`system_server_font` and `activity_thread_font` are internal scheduler domains.
They are not saved in the custom hook-chain override, and restoring the hook
chain returns only to the compat/field-rewrite recommended template.

System-server route implementation classes now live under `runtime.systemserver`. Flavor entry points still use the same install,
diagnostic, policy, and process-check protocols; this is package
classification only, not a route behavior change.

## Experiment Ledger

| Date       | Route                                               | Change                                                                                                                                                                                                                            | Status                                     | Notes                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |
|------------|-----------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2026-10-01 | WeChat DPI                                          | Legacy getter hook returns a detached metrics copy instead of mutating the caller's object                                                                                                                                        | active / shared                            | Same ownership as Modern. The window viewport keeps Resources metrics                                                                                                                                                                                                                                                                                                                                                                                                          |
| 2026-10-01 | WeChat DPI                                          | Shared static table adds WeChat 8.0.78 / versionCode 3180 on `le5.f` getters `d` and `e`                                                                                                                                          | active / shared                            | Legacy uses the same table. Bottom-tab scale stays off. Device class check was the Tinker dex on the Modern phone                                                                                                                                                                                                                                                                                                                                                              |
| 2026-10-01 | shared app-process font                             | Legacy SP field rewrite skips the extra multiply when scaledDensity already carries the target factor                                                                                                                             | active / shared                            | Same policy as Modern. Device confirmation is the Modern pack `20261001-003852-2`. The nested-call guard still stays set so the delegated unit hook and paint hook do not scale that call again                                                                                                                                                                                                                                                                                |
| 2026-09-30 | shared app-process viewport                         | Legacy metrics override reuses a read by returned metrics and generation, without a configuration stamp                                                                                                                           | active / shared                            | Legacy calls `applyMetricsOverride` directly. A hit now returns before the font-store and virtual-display reads                                                                                                                                                                                                                                                                                                                                                                |
| 2026-09-30 | shared app-process viewport                         | Record reused display-metrics skips after the timed interval, every 50 hits                                                                                                                                                       | active / shared, device validation pending | Legacy inherits the shared read through `app/src/main/java`. The hit path increments a counter and emits one skipped event per 50 hits after duration is captured                                                                                                                                                                                                                                                                                                              |
| 2026-09-29 | shared app-process viewport                         | A display-metrics hit compares returned density, pixel size, and a generation; it does not read configuration or the font store                                                                                                   | active / shared, device validation pending | Legacy inherits the shared read through `app/src/main/java`. Generation bumps on `updateConfiguration`, preference commits, and virtual-display replacement. The first reuse still read configuration and left Xiaohongshu `p50Us` at 9                                                                                                                                                                                                                                        |
| 2026-09-29 | shared app-process viewport                         | Reuse an unchanged `Resources.getDisplayMetrics` read for one second before font observation and viewport resolution                                                                                                              | superseded                                 | First reuse still read configuration on every hit                                                                                                                                                                                                                                                                                                                                                                                                                              |
| 2026-06-01 | system                                              | Restore launch-activity-item config mutation                                                                                                                                                                                      | rejected                                   | Did not hold final viewport state                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| 2026-06-01 | system                                              | ActivityRecord config-dispatch hook                                                                                                                                                                                               | shared-modern evidence                     | Required for apps whose layout depends on Activity-level config, but not currently installed by legacy                                                                                                                                                                                                                                                                                                                                                                         |
| 2026-06-01 | system                                              | DisplayManagerInfo UID-gated hook                                                                                                                                                                                                 | shared-modern evidence                     | Required for display metric consumers bypassing app-process Display, but not currently installed by legacy                                                                                                                                                                                                                                                                                                                                                                     |
| 2026-06-01 | compat                                              | ResourcesKey empty override fill                                                                                                                                                                                                  | active                                     | Shared helper; preserves viewport in resource key path                                                                                                                                                                                                                                                                                                                                                                                                                         |
| 2026-06-01 | compat                                              | App-process Display / WindowMetrics supplement skipped for system mode                                                                                                                                                            | current design                             | Resources bridge still installs; the design gate only applies to display/window supplement hooks                                                                                                                                                                                                                                                                                                                                                                               |
| 2026-06-01 | legacy                                              | FlutterJNI viewport metrics bridge                                                                                                                                                                                                | active, per-app guarded                    | Covers Flutter/mixed shells; guard scope per target                                                                                                                                                                                                                                                                                                                                                                                                                            |
| 2026-06-02 | legacy                                              | LaunchActivityItem post-construction object mutation                                                                                                                                                                              | active                                     | Aligns legacy launch delivery with modern                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| 2026-06-04 | WeChat target-field                                 | Keep app-specific route alongside generic hooks, share target-field runtime property handling, and add the required write-side companion route for versions that need it                                                          | superseded                                 | Detailed version-specific evidence lives in `docs/private/wechat-target-field.md`                                                                                                                                                                                                                                                                                                                                                                                              | Replaced by the WeChat DisplayMetrics DPI route; do not reintroduce target-field hooks without fresh evidence |
| 2026-06-04 | WeChat 8.0.71 target-field                          | Replace stale constructor-field route with the verified getter/setter route shape                                                                                                                                                 | superseded                                 | Shared route registry evidence lives in `docs/private/wechat-target-field.md`                                                                                                                                                                                                                                                                                                                                                                                                  | Kept as locator history only |
| 2026-06-07 | font system emulation                               | Add `system_server_font` as an explicit internal domain for `Configuration.fontScale`                                                                                                                                             | active / superseded fallback               | Douyin and Bilibili repros stopped flickering when only system_server font mutation was skipped; app-process font domains still scaled text                                                                                                                                                                                                                                                                                                                                    | Kept as planner/runtime diagnostic state, not a compat custom-chain switch |
| 2026-06-07 | font system emulation                               | Route `FONT_SCALE` through field-level system_server scheduling and allow it only at `launch-activity-item`                                                                                                                       | active                                     | Unit policy tests cover viewport multi-entry scheduling and font launch-only scheduling                                                                                                                                                                                                                                                                                                                                                                                        | Avoids later config-dispatch writes that can surface as `CONFIG_FONT_SCALE` relaunches |
| 2026-06-07 | shared app-process viewport                         | Relative-scale app-process borrow targets preserve small-window dp geometry while applying target density in ResourcesImpl / ResourcesRead metrics                                                                                | active                                     | Shared unit tests cover ResourcesImpl and ResourcesRead window density compensation                                                                                                                                                                                                                                                                                                                                                                                            | This is package-neutral shared behavior; legacy inherits it through `app/src/main/java` |
| 2026-06-08 | WeChat DPI                                          | Replace the old target-field route with the WeKit-style DisplayMetrics post-processing route as the official WeChat independent path                                                                                              | active                                     | Runtime check confirmed property publication, hook installation, and mutation callback on `q35.f` for 8.0.71; TabIconView supplement was rejected as disproportionate at DPIS custom values; details in `docs/private/wechat-target-field.md`                                                                                                                                                                                                                                  | DPIS now only mutates returned `DisplayMetrics` |
| 2026-06-09 | WeChat DPI                                          | Move method discovery to a shared WeKit-style DexKit locator with the static version table as fallback only                                                                                                                       | active                                     | Unit/source tests cover the DexKit rule, fallback ownership, and shared runtime mutation formula                                                                                                                                                                                                                                                                                                                                                                               | Locator matches the `MMDensityManager` / `screenResolution_target_field` signature and logs whether `dexkit` or `static-route` installed hooks |
| 2026-06-09 | WeChat DPI                                          | Shared DexKit locator now falls back to extracted module native library paths when LSPosed cannot load `libdexkit.so` from `base.apk!/lib/...`                                                                                    | active / shared                            | Modern real-device WeChat 8.0.74 / versionCode 3120 reached `hook ready`, `callback hit`, and `applied` after this shared fix; legacy has source/unit coverage but no separate device run in this note                                                                                                                                                                                                                                                                         | Keep as shared locator behavior, not a compat-specific route change; 3120 / `j65.f` is also in the static fallback table |
| 2026-06-15 | shared app-process font                             | Add an event-gated `resources_font` scheduler for Resources read-path font conflicts                                                                                                                                              | active / shared                            | Bilibili `resources_font`-only repro on Modern showed base/target font-scale alternation in shared Resources read paths; unit tests cover the shared scheduler semantics and Legacy inherits the fix through `app/src/main/java`. TapTap system-font repro later showed the same shared metrics-read boundary: read-side configuration writes must stay off, while metrics should not be downgraded from the target font factor by a lower system config                       | Read-conflict target suppression outranks Compose base suppression; non-Compose observations must not clear an established read-conflict target state. Compat `resources_font` uses `ResourcesImpl` as a low-frequency metrics seed plus `ResourcesRead` fallback; when `ResourcesRead` is installed only for font it skips viewport target resolution and `VirtualDisplayState` reuse while keeping metrics density synchronized with configuration; system font emulation does not let `ResourcesRead(getConfiguration)` force target `fontScale` on every read, but `ResourcesRead(getDisplayMetrics)` may fill `scaledDensity` from the target factor so read-side metrics do not downgrade an already-targeted font scale; Compose diagnostics can detach after the read-conflict target event is established; `ResourcesManager` write-side hooks remain for viewport and system font emulation |
| 2026-06-26 | Chrome WebAPK owner routing                         | Shared WebAPK owner extraction exists, but Legacy does not claim Chrome content app-process carrier support                                                                                                                       | active / partial                           | Shared unit tests cover conservative owner parsing; Modern device validation proves Android Resources and Chromium Java `WindowAndroid` can see WebAPK owner scale in Chrome, but that probe is installed from Modern package-ready libxposed routing                                                                                                                                                                                                                          | WebAPK splash package can still receive normal package hooks; Legacy does not add a separate Chrome WebAPK carrier route or promise final renderer scaling |
| 2026-06-27 | Chrome WebAPK logging policy                        | Keep WebAPK owner evidence low-volume and gate detailed Chromium probes                                                                                                                                                           | shared logging rule                        | Modern now installs the Chromium Java viewport probe only when `debug.dpis.webapk.chromium_probe_package` explicitly matches Chrome in a debug build; shared owner bridge logs only state changes and value changes                                                                                                                                                                                                                                                            | Legacy inherits the shared owner parser/log wording but still does not claim Chrome content carrier support |
| 2026-06-28 | Legacy Chrome system marker handoff                 | Legacy `system` mode on Chrome can publish a fresh system marker, but the visible app-process effect remains metrics-only                                                                                                         | active / Chrome-specific evidence          | On `192.168.5.131:5555`, Chrome saved as `viewport.mode=system` first logged `LegacyResourcesRead(getConfiguration)` marker miss `reason=stale`, then the same launch observed `result=hit, ageMs=24` plus `LegacyResourcesManager (metrics) override`. `dumpsys activity` still showed Chrome `CurrentConfiguration` at the platform `sw462dp / 374dpi`, so this route proved marker publication/app-process handoff rather than launch-time Activity `Configuration` rewrite | Treat “Legacy Chrome system mode not effective” as “launch-time system marker is consumed by the app-process bridge, but legacy does not currently provide a stronger Chrome system viewport mutation path” rather than as a pure scope/config failure |
| 2026-06-28 | Legacy Chrome stronger launch-time system viewport  | Let legacy `launch-activity-item` commit viewport `Configuration` for resolved system-mode packages, not only publish a marker                                                                                                    | active                                     | `PerAppDisplayConfigSource` already suppresses compat/off viewport targets in system_server, so `applyConfiguration(configuration, environment)` at `launch-activity-item` strengthens only `system` / `auto->system` launches. Focused unit tests cover `system` rewriting `462x1001@374dpi` to `924x2002@187dpi` and `compat` staying unchanged                                                                                                                              | This is intentionally stronger than the earlier marker-only legacy behavior. If Chrome still ignores content scaling after this, the remaining boundary is Chromium content consumption rather than launch-time Activity `Configuration` handoff |
| 2026-06-28 | Legacy Chrome launch-item object mutation follow-up | Mirror the modern two-stage launch path in legacy by mutating constructed `LaunchActivityItem` fields (`mCurConfig`, `mOverrideConfig`) after constructor proceed, not only raw constructor args before proceed                   | active                                     | On `192.168.5.131:5555`, Chrome kept consuming fresh system markers in app-process logs while no legacy `launch-activity-item apply` evidence appeared from the constructor-args path. The likely missing boundary was post-construction object fields on platform builds where the effective launch config is held on the item instance                                                                                                                                       | Keep logs low-frequency and package-scoped. This route is meant to prove whether legacy can hand the stronger launch configuration to Chrome before blaming Chromium renderer consumption |
| 2026-09-04 | shared app-process viewport                         | Reject incomplete display configurations for viewport mutation, preserve eligible font-only updates, reject non-positive font-scale writes, and derive Display fallbacks from valid physical metrics when no shared record exists | active / device validation pending         | Affected-app diagnostic showed `ResourcesImpl` / `ResourcesRead` writes against zero-valued display fields and skipped `Display` overrides with `no_package_scoped_override`                                                                                                                                                                                                                                                                                                   | Shared behavior is inherited from `app/src/main/java`; validate on Legacy before calling the startup stall resolved |

2026-10-01 viewport finding: the shared relative-scale resolver now keeps the first process baseline, applies that baseline before the app-process borrow branch, does not cache relative results across virtual-display publication, and app-process `Resources.getSystem()` explicitly skips app viewport overrides. Display callbacks reuse the current physical-size result instead of deriving from transformed density. This prevents a second ratio pass such as `360->432` followed by `432->518`; Legacy inherits the shared fix.
2026-10-01 viewport ownership boundary: shared app-process configuration, ResourcesManagerKey, and DisplayMetrics supplements defer only when the effective viewport mode resolves to `system` for a relative target and system hooks are enabled. Explicit `compat` and WebAPK owner routes remain app-owned. Each defer now emits `system_server_owns_relative_viewport` evidence for diagnostic packages.
2026-10-05 viewport ownership boundary: a system-owned relative read defers only when that
configuration or display density already carries the published result. A still-physical display
configuration is written once to the same dp and density. Legacy inherits the shared fix. A
configuration that already matches the result is still not multiplied again.
2026-10-05 display metrics: system-owned viewport still installs the shared app-process Display
metrics hooks, so `getRealMetrics` density matches Resources. Legacy inherits that install gate.
Window-bounds replacement stays with system_server. `getRealMetrics` stays on the display pixels.
`getMetrics` keeps a real window's own pixels at that same density. Legacy inherits the shared rule.
A matching dpi does not skip a metrics object whose density or scaledDensity still disagree.
2026-10-05 window aspect: Legacy inherits the shared ResourcesImpl rule. A relative configuration
whose long-to-short ratio differs from the published display result by more than 0.15 stays a window
and is not published as the display. A display-sized callback reuses the remembered window only when
they share an orientation.
2026-10-05 copied display result: Legacy inherits the shared rule. System mode records window bounds
without replacing the rect. A configuration that already carries the full display result is
rewritten to the remembered window's height when that window has a different shape. The stored
display pixels stay unchanged.
2026-10-05 display evidence: Legacy inherits the shared bridge retain. A Display metrics mutation
that happens before the diagnostic bridge can deliver is written once later with the original
`densityDpi` before and after. The performance counter is not incremented a second time.
2026-10-05 Chrome tab-grid limit: Legacy inherits the shared limit. Relative scale
leaves the physical width beside the published result. Chrome's page snapshot
animates with the physical width while the toolbar and tab card use the published
width. The animation does not change Configuration or WindowMetrics, so the shared
viewport hooks cannot see those frames. A Chrome-only snapshot route was not added.

2026-10-09 shared display-pixel ownership: a relative-scale diagnostic showed an
active same-orientation window where stale viewport pixels replaced a taller
display metrics callback, producing stretched image edges. Shared
`ResourcesRead` now keeps display-sized physical pixels whenever a window
episode is active and does not reuse cached virtual-display pixels for that
callback. Legacy inherits this boundary.
2026-10-10 shared fullscreen ownership: a relative-scale system-mode app
stuttered on 2.3.1 because the app process rewrote a still-physical fullscreen
configuration that 2.3.0 left with system_server. Shared ownership now defers
that fullscreen configuration, including before the relative result is
published. A smaller window is still rewritten in the app process. Legacy
inherits this boundary.
2026-10-10 shared fullscreen update: `ResourcesImpl.updateConfiguration` and
`Resources.getConfiguration` leave a system-owned fullscreen configuration
unchanged. A feed trace showed a one-percent app-process change before a long
run of main-thread inflation. A smaller window is still rewritten in the app
process. Legacy inherits this boundary.

## Safety Rules

- Changes under `app/src/modern/java/` should not be described as legacy
  behavior.
- Changes under `app/src/main/java/` are shared and must be reviewed for both
  100 and 101.
- For legacy system route, require system_server install evidence plus
  callback/mutation evidence. `hook ready` alone is not enough.
- Per-app stability guards (e.g., splash filter, Display/WindowMetrics disable,
  WebView supplement skip, Flutter activity scope) are configured per target
  package. Do not change default boundaries without per-target evidence.
- Treat Bilibili/Douyin flicker findings as evidence for the generic
  `FONT_SCALE` field policy, not as package-name recommendations. Hook-chain
  restore default clears the compat custom override and returns to the compat
  recommended template; it must not grow a Bilibili/Douyin default list.

## Update Log

- 2026-10-17 test2: user reports a large but incomplete reduction of jank with
  test1 on Android 10 at absolute width 450dp. This is qualitative device
  feedback, not a measured before/after CPU result. Legacy now reuses completed
  getConfiguration overrides for up to 250ms when the entire Configuration,
  resource identity, package, store identity and write generation match.
  A detached Configuration copy prevents in-place external mutation from
  corrupting the comparison. Hits do not renew the deadline. Reads spanning
  a generation change are not cached. Configured font scaling is excluded
  because its scheduler has additional ownership state. The metrics miss path
  shares this configuration cache; Modern hook wiring and getSystem semantics
  remain unchanged. The cache policy and generation accessor are shared/tested
  utilities, but only Legacy installs the new read fast path. Further device
  performance improvement remains unverified pending test2 installation.
  Investigation also found that VirtualDisplayState.publish unconditionally
  bumped the generation even for identical output, defeating stable read reuse
  across interleaved configuration/metrics reads. Identical display/record
  publication now keeps the generation while refreshing timestamps. Changes to
  display fields or record ownership/target/provenance still invalidate; explicit
  clears and framework configuration writes also retain invalidation. This is
  shared with Modern and covered by cross-flavor regression tests.

- 2026-10-17: Android 10 performance test candidate (device result unverified).
  SDK 37 release lint also exposed a pre-existing BlockedPrivateApi warning in
  ViewportOverride's optional windowConfiguration reflection. A method-scoped
  suppression documents that injected-framework access, without changing its
  reflection/null fallback or disabling lint globally.
  Legacy resource reads now guard internal configuration/getSystem callbacks
  with try/finally and retain resource identity when invoking shared overrides.
  A metrics cache hit returns before configuration/property resolution; misses
  explicitly keep the previous configuration fallback, then resolve metrics
  with the active store. ResourcesImpl and ResourcesManager configuration
  writes invalidate the existing one-second, generation-bound metrics cache.
  ResourcesManager lookup accepts the Android Q Locked suffix; WindowMetrics
  installation is skipped below API 30. These initialization compatibility
  changes are not proof of the sustained CPU cause. Modern/shared runtime
  algorithms are unchanged. CPU top samples establish high main-thread use but provide no
  sampled Java stacks; device A/B performance and viewport checks remain needed.

- 2026-06-21: shared feedback diagnostic LSPosed timeline semantics now keep
  same-timestamp runtime events in stage order (`begin`, `applied`/`skipped`,
  `end`), and explicit `DPIS_VIEWPORT*` evidence no longer misclassifies to the
  generic font route when the message also mentions `fontScale`. Shared
  diagnostic runtime hotpath evidence now covers selected compat
  viewport/resources boundaries including runtime marker observation,
  `ResourcesManager` override, `ResourcesImpl` observe/override/stable target,
  and `ResourcesRead` configuration/display-metrics overrides.
- 2026-06-21: shared app-process viewport diagnostics now include first-hit plus
  counted-sample `runtime.appprocess.DisplayHookInstaller` and `runtime.appprocess.WindowMetricsHookInstaller`
  runtime-hotpath evidence. Repeated callback evidence carries `hitCount` and
  `suppressedCount`, aimed at rapid-scrolling repros where callback hit versus
  skipped supplement behavior needs to be separated before drawing conclusions.
- 2026-06-21: shared diagnostic log behavior now carries
  `diagnosticLogFingerprint=diag-log-2026-06-21-counted-hotpath-v1` in the app
  hook plan and Display/WindowMetrics supplement readiness/probe evidence. Bump
  `RuntimeDiagnosticLogFingerprint.VALUE` whenever runtime diagnostic log
  semantics change.
- 2026-06-01: initial tracker created.
- 2026-06-01: shared modern route evidence confirmed auto absolute-width route
  needs ActivityRecord config-dispatch plus DisplayManagerInfo in addition to
  app-process Resources/Display supplements. legacy does not currently
  install these two shared modern system_server entries.
- 2026-06-01: added FlutterJNI viewport metrics bridge for Flutter/mixed
  shells; ViewRoot probing is inactive diagnostic evidence.
- 2026-06-02: added LaunchActivityItem post-construction object mutation to
  align legacy launch delivery with modern.
- 2026-06-03: consolidated app-process viewport policy into a domain switch
  with per-app guard configuration.
- 2026-06-04: WeChat target-field route no longer suppresses generic app-process
  hooks; shared target-field runtime property handling now writes and reads with
  persistent fallback. Legacy shares the write-side companion route support
  used by versions that need it.
- 2026-06-08: WeChat target-field hooks were superseded by the official WeChat
  DPI route. The compat app-specific route now hooks no-arg `DisplayMetrics`
  methods on the version-specific WeChat density-manager class and
  post-processes `density`, `densityDpi`, and `scaledDensity` from the
  configured DPI.
- 2026-06-07: diagnostic overrides showed that skipping only system_server
  `Configuration.fontScale` removes Douyin and Bilibili flicker while
  app-process font domains can still scale text. The route is now represented
  as the explicit internal `system_server_font` domain for planner/runtime
  scheduling evidence, not as part of the compat custom-chain switch group.
- 2026-06-07: field-level system_server mutation scheduling now keeps viewport
  multi-entry behavior but narrows `FONT_SCALE` to launch-time configuration
  mutation. This moves the Bilibili/Douyin relaunch mitigation into DPIS
  scheduling instead of relying on users to know which sub-route to disable.
- 2026-06-07: documented the semantic boundary between requested hook domains
  and effective system_server execution. Bilibili/Douyin remain reproduction
  evidence for package-neutral scheduling; they are not built-in recommended
  hook-chain targets.
- 2026-06-07: restored the product boundary that custom font hook domains edit
  only the compat/field-rewrite chain. System-mode font routes remain internal
  scheduled routes and no longer share the custom-chain switch state.
- 2026-06-22: shared Paint/TextPaint field-rewrite fallback now uses libxposed
  argument replacement instead of a post-call `setTextSize` rewrite. It remains
  independently selectable, but observes TextView/layout owned writes and keeps
  Paint provenance as the fallback write authority. Paint fallback provenance is
  resolved in one tracker pass per write. Active diagnostics include Paint
  fallback caller summaries so shared Legacy/Modern field-rewrite evidence can
  distinguish self-drawn fallback use from stronger TextView/layout candidates.
- 2026-06-07: updated the route map to show system font mode explicitly and to
  split the app-process Resources bridge from the Display / WindowMetrics
  supplement that is skipped when viewport resolves to system.
- 2026-06-07: shared modern system_server package selection is now
  field-aware per entry. This records shared-code behavior for 100/101 review;
  legacy still does not install the shared modern system_server entries.
- 2026-06-07: shared app-process relative-scale borrow handling now keeps
  small-window width/height dp owned by the window manager while deriving target
  density locally for `ResourcesImpl` and `ResourcesRead(getDisplayMetrics)`.
  This avoids using compat app-process routes to publish display baselines from
  a borrowed small-window result.
- 2026-06-08: shared relative-scale app-process consumers now classify matching
  local or target runtime records as borrow targets. This covers flexible-window
  mixed configurations where `smallestWidthDp` has reached the target but
  width/height and density still describe the source window.
- 2026-06-09: shared WeChat DexKit locator gained an extracted native library
  fallback for LSPosed module classloaders. This preserves DPIS legacy native
  packaging used by existing HyperOS native proxy paths while allowing DexKit
  to load from `/data/app/.../lib/<abi>/libdexkit.so` when
  `System.loadLibrary("dexkit")` cannot resolve `base.apk!/lib/...`.
- 2026-06-09: shared review follow-up tightened WeChat DPI config recovery.
  Legacy `wekit_dpi` migration no longer overwrites an official mirror value,
  3120 / `j65.f` is recorded as a static fallback, save failures no longer
  publish runtime properties, and recovery always clears the fixed WeChat
  property pair when no enabled WeChat DPI value exists.
- 2026-06-13: config-source ownership is now local-authoritative for the
  module app. LSPosed remote preferences remain a runtime delivery copy for
  hook processes, while `createLocalUiModuleConfigStore` reads only local
  `dpi_config` and never treats remote values as UI, backup, migration, or
  app-list input. Runtime-only fallback stores such as system properties plus
  XSharedPreferences remain explicit hook-side compatibility inputs.
- 2026-06-13: real config saves now route through a single runtime delivery
  resync action after successful local persistence. Per-field system property
  publishers still provide immediate hot-path mirrors, while
  `RuntimeConfigDelivery.publishLocalSnapshotAfterSave()` republishes the local
  authoritative snapshot to LSPosed remote preferences for hook-process startup
  and reconnection.
- 2026-06-14: shared runtime property fallback no longer lets global debug
  mirrors mark a package as configured. This keeps boot-time app-process hooks
  able to fall back to persisted LSPosed delivery when always-running targets
  start before DPIS has replayed volatile per-package runtime mirrors.
- 2026-06-26: shared app-process Resources and Display hooks can now resolve a
  Chrome WebAPK owner only when the carrier process is `com.android.chrome` and
  launch/lifecycle evidence identifies `SameTaskWebApkActivity` with an
  `org.chromium.webapk.*` owner. The hot path reads that owner's runtime
  property store; Legacy does not add a separate WebAPK carrier route. Modern's
  Chrome package-ready Chromium Java probe is diagnostic evidence for Modern
  only and does not change Legacy support claims.
- 2026-10-04: Small-window sizing uses each resource callback's own pixels at
  one relative scale. A size that is not the display replaces the remembered
  window; a display-sized callback keeps it. Two consecutive fullscreen
  observations that match the display, including origin, end the episode.
  Source identity is evidence only. A top-left split or freeform that still
  fits inside the display does not clear the global viewport. When the stored
  pixels are only a window, a larger origin rect becomes the display baseline
  before that stale viewport is cleared. A complete relative-scale marker,
  published at the ResourcesManager boundary and reused by ResourcesImpl and
  Display, replaces a second application of the same scale and wins over a
  conflicting in-memory display record while physical pixels stay. When window
  metadata is missing, a configuration whose aspect differs from that marker
  stays a window and keeps its physical bounds. A display-sized metrics read
  keeps the display pixels. Hot reload drops
  the remembered window. Window frame override stays off. Consistency snapshots
  and layout diagnostics stay bounded evidence and are not the size source.
  Scope is platform windowing mode plus bounds versus maximum bounds, with
  optional ColorOS task reflection. The resolver keeps the evidence source so
  another vendor detector can be added without changing viewport callers. A
  sibling resource object may briefly rewrite the previous window, an
  off-origin full-size rect is not fullscreen, and a short window may keep its
  own smallest width at the same density.
- 2026-10-05: A complete display marker does not replace a window callback's
  height. At 120%, 1080x1920 stays 768dp and 1079x1439 stays 576dp, both at
  density 400. system_server keeps the display-shaped configuration. A window
  configuration is still scaled in the app process. Display pixels 1080x2376
  stay on the display scale 432x950, including while a window is active.
  A relative configuration whose aspect differs from that display result is a
  window even when no window bounds have been recorded, and it does not replace
  the display pixels. A display-sized callback reuses the remembered window
  only when that window has the same orientation.
  Shared app-process code; Modern and Legacy see the same resource route.
- 2026-10-05: Chrome's tab grid is a shared relative-scale limit. The page snapshot
  animates from the physical width while the toolbar and card use the published
  width. The clicks do not change WindowMetrics, so the shared viewport route
  cannot see those frames. No Chrome-only route was added.
- 2026-10-11: A system-mode preference without a current system_server result
  marker no longer suppresses the app-process fullscreen fallback. The app route
  defers only after a current marker with system_server provenance; this keeps
  AUTO effective when system hooks are enabled but their mutation route did not run.
- 2026-10-12: Shared with Modern. AUTO relative launch is applied in modern
  system_server from physical max bounds. Explicit compat is stripped before
  delivery. A system_server launch write stopped the cover-edge stretch and
  was not kept, because compat must not require a system-framework hook.
  Legacy still skips a compat viewport if one arrives. Compat Display
  callbacks stay untouched, including density.
