# SonarQube

DPIS uses the SonarQube Gradle plugin (`org.sonarqube`) for an optional
static-analysis job. Gradle remains responsible for compilation, unit tests,
and JaCoCo coverage generation. The analysis is advisory for now: it does not
wait for or enforce a SonarQube quality gate, and it does not change GitHub
branch protection.

The CI job passes `sonar.branch.name` on `push` / `workflow_dispatch`, and
pull-request keys on `pull_request`. Do not run a branch scan without a branch
or PR parameter; that publishes onto `main`.

## Enable the GitHub job

Create a SonarQube Cloud project (or point the configuration at a compatible
SonarQube Server) and add these repository settings:

- Repository variable `SONAR_ENABLED=true`
- Repository secret `SONAR_TOKEN`
- Repository variable `SONAR_PROJECT_KEY`
- Repository variable `SONAR_ORGANIZATION` when using SonarQube Cloud
- Repository variable `SONAR_HOST_URL` when using a server other than the
  default `https://sonarcloud.io`

Because this integration uses CI-based analysis for Gradle test coverage,
disable SonarQube Cloud Automatic Analysis in the project's
`Administration -> Analysis Method` settings. SonarQube Cloud does not allow
Automatic Analysis and CI-based analysis to run together.

The job is intentionally disabled until `SONAR_ENABLED` is set. This keeps a
fresh checkout's existing build, test, and lint checks independent from the
external SonarQube project setup. Pull requests from `release-please--`
branches are also skipped because release-please has its own CI flow.

## Local analysis

From the repository root, run the tests and coverage report first:

```bash
./gradlew :app:testAllDebugUnitTests :app:jacocoModernDebugUnitTestReport
```

Then run the Gradle `sonar` task with the project key, organization, host URL,
and token configured in your environment:

```bash
./gradlew sonar -Dsonar.host.url=https://sonarcloud.io \
  -Dsonar.token="$SONAR_TOKEN" \
  -Dsonar.projectKey=Kwensiu_DPIS \
  -Dsonar.organization=kwensiu \
  -Dsonar.branch.name="$(git branch --show-current)"
```

The checked in `sonar-project.properties` supplies the source, binary, test, and
coverage paths shared by local and CI analysis. Root `build.gradle.kts` joins
backslash-continued values so `sonar.coverage.exclusions` can stay a readable
list. A parser that only keeps lines containing `=` drops that list and
publishes an empty coverage gate. Android subprojects are skipped by the Gradle
plugin because `org.sonarqube` 6.3.1 still looks up AGP's removed
`AppExtension` / `BaseExtension` types; root analysis reads those explicit paths
instead of Android variant metadata.

The report analyzes Kotlin and Java sources. Native C++ sources and generated
resources are excluded for this first integration. Modern Debug is the primary
coverage input; Legacy unit tests still run as a separate Gradle prerequisite
in CI.

## Inspect results

Agents read uploaded Cloud analysis through the SonarQube MCP (`Kwensiu_DPIS`).
Use `list_pull_requests` or `list_branches`, then quality gate, measures, and
issues tools. Do not curl Sonar REST or scrape GitHub check logs for the same
facts. MCP does not replace Gradle tests, JaCoCo, or the scanner job.
