# 诊断性能证据架构

本文定义 DPIS 反馈诊断从“运行日志”演进为“模块实际执行证据”的目标
语义。本文先于实现，避免把当前 `RuntimeEvents` 或
`RuntimeTransport` 的类结构误认为最终领域模型。

## 已确认的产品决策

- 诊断由用户一次启动。
- DPIS 重启目标应用并开始采集。
- 用户复现后返回 DPIS，返回动作同时结束运行证据采集和 Perfetto 采集。
- 不要求用户再次点击“继续采集”或“停止采集”。
- 一般诊断时长不超过 1 分钟；Perfetto 采集预算按约 60 秒设计。
  ring buffer 与导出上限均为 128 MiB，避免高频调度/ftrace 事件在启动或快速
  滑动期间覆盖前段 trace，或在导出阶段被第二次截断。
- 如果用户更早返回，立即停止并打包；不为了凑满 60 秒而延迟结束。
- 目标进程负责记录实际 hook 执行证据；DPIS UI 进程只负责控制会话、停止采集和导出。
- 首期覆盖所有 runtime route，而不是只覆盖字体 route：
  `font`、`viewport`、`typeface`、`wechat_dpi` 和 `system_server`。
- 诊断模式允许较宽松的采集粒度，但普通运行路径不能承担诊断级开销。
- 默认不记录文本内容；可以记录类名、数值输入输出、调用者摘要和慢调用
  样本。
- 诊断只能报告观察和时间关联，不能仅凭一次命中直接断言“DPIS 导致卡顿”。

## 核心领域对象

### DiagnosticSession

一次用户可见的反馈诊断会话。它由 DPIS UI 进程创建和关闭，拥有全局
session id、目标包、开始时间、结束原因和采集状态。

它不是实际 hook 执行的所有者；它只定义采集窗口和导出边界。

### ProcessEvidenceSession

某个被 LSPosed 注入的进程在一个 `DiagnosticSession` 窗口内建立的本地
证据采集上下文。它至少包含：

- session id
- package name
- process name
- pid
- module build/runtime marker
- route plan
- hook installation state
- counters
- latency histograms
- slow-call samples
- transport health

一个 DiagnosticSession 可以包含多个 ProcessEvidenceSession，例如抖音主进程
和 `com.google.android.webview` 进程。

### RouteEvidence

某个 runtime route 在目标进程或 `system_server` 中实际执行的结构化证据。
RouteEvidence 不等同于日志文本。

证据阶段固定为：

```text
hook_installed
callback_entered
decision
mutation
```

其中 `hook_installed` 只能证明安装；`callback_entered` 才能证明回调进入；
`decision` 说明允许修改或跳过的原因；`mutation` 才能证明运行对象实际被
改变。

### PerformanceMeasurement

某个 RouteEvidence 的耗时和执行上下文：

- durationNs
- thread name / tid
- 是否主线程
- route
- operation
- decision
- mutation result
- 异常状态

高频调用不逐条持久化 PerformanceMeasurement，而是在目标进程本地聚合。
慢调用和异常可以作为少量样本导出。

### CorrelationResult

将 DPIS 运行证据与 Perfetto 的调度、帧和输入时间线进行关联后的结论。
结论等级为：

- `observed`：观察到目标 route 执行或 mutation。
- `correlated`：DPIS 执行时间与长帧或主线程压力存在时间重叠。
- `likely_contributor`：DPIS 执行耗时在相关帧预算中占有可解释比例。
- `not_supported`：证据不足，不能支持归因。

`likely_contributor` 不是“已证明唯一原因”；其它应用线程、Binder、I/O、
CPU 频率和系统调度因素仍需保留。

## 执行证据链

```text
hook install
  -> callback entered
  -> route decision
  -> skip or mutation
  -> local counter/histogram
  -> periodic aggregate snapshot
  -> cross-process transport
  -> DPIS export
  -> Perfetto correlation
```

每条链路必须能区分：

- 没有安装；
- 已安装但没有回调；
- 有回调但被跳过；
- 允许修改但实际没有改变；
- 实际修改成功；
- 目标进程产生了统计但传输失败；
- 目标进程没有建立证据会话。

空统计不能只显示 `entries: 0`。

## 目标进程采集模型

实际 hook 执行进程拥有 `ProcessEvidenceSession`。高频路径只执行低成本
操作：

- 原子计数；
- `System.nanoTime()`；
- 低成本延迟直方图；
- 跳过原因计数；
- 慢调用阈值判断；
- 少量抽样样本。

高频路径不得执行：

- 每次调用写文件；
- 每次调用构造完整 JSON；
- 每次调用获取完整 Java 堆栈；
- 每次调用进行 Binder/UI 进程通信；
- 每次调用启动 root shell。

目标进程通过周期性快照传输聚合结果。建议快照按 500ms～1s 发送，
慢调用和异常使用单独的小容量样本通道。

`system_server` 是同一 transport 的特殊生产者：它不维护 UI 进程的
`DiagnosticSession` 静态对象，而是通过会话 marker/property 发现活动会话。
其 viewport hook 只能在既有日志 gate 已决定输出时发送目标包事件，避免在
高频系统生命周期回调中另起逐条采样流。首期事件记录实际 mutation 与有限的
skip 原因；安装摘要没有目标包，不能作为单个诊断目标的 mutation 证据。

## RouteEvidence 的最小字段

```text
sessionId
packageName
processName
pid
route
operation
stage
decision
reason
mutation
inputSummary
outputSummary
durationNs
threadName
tid
isMainThread
timestampElapsedNanos
```

`inputSummary` 和 `outputSummary` 只允许记录诊断所需的数值、类型和状态；
不记录用户文本内容。

## 性能聚合字段

每个 route/operation 至少聚合：

- calls
- applied
- skipped
- skip reasons
- measured calls
- p50 / p95 / p99 / max duration
- main-thread calls
- main-thread accumulated duration
- slow-call count
- exception count
- first and last monotonic timestamp

聚合必须按进程分组，不能把 WebView 或其它子进程混入主进程统计。

## Perfetto 生命周期

Perfetto 由 DiagnosticSession 控制：

1. 诊断会话准备完成后启动。
2. 目标应用重启并进入前台。
3. 用户在目标应用内复现。
4. 用户返回 DPIS。
5. DPIS 立即停止 Perfetto 和 runtime evidence capture。
6. DPIS 读取并打包 trace 与聚合证据。

诊断页上的 Perfetto 是可选项，默认关闭。打开后由 perfetto 客户端用
`-o` 写到 `/data/local/tmp`。不要改成 `write_into_file`：traced
无法在这个目录建文件，进程会马上退出，诊断包里就没有 trace。
缓冲是 128 MB、`DISCARD`，保留从诊断开始的内容，满了就不再收下一段。
自动结束诊断时，trace 时长等于所选诊断时长；未开启自动结束时，上限是
86400 秒。返回 DPIS 仍然立刻停止。超过 128 MB 的文件不导出。导出阶段按
3 MiB 对齐分块读取并 Base64 解码，避免把整段编码文本一次性放入内存；后续
仍可继续演进为直接文件流转移。

Perfetto 至少需要覆盖：

- scheduler / thread state
- frame timeline / gfx
- input
- 进程创建、退出和重命名
- DPIS 自定义 counter 或慢调用 trace slice

首期配置主动移除了 `view`、`binder_driver` 和全进程 `process_stats` 扫描，
因为它们在高频目标应用上容易制造大量与当前卡顿判断无关的事件。若后续诊断
实际发现现有 scheduler、frame timeline、gfx、input 和进程生命周期证据不足以
证明某类卡顿现象，再根据具体证据缺口恢复相应数据源，而不是默认全部开启。

DPIS 自定义 trace 不应为每个高频 callback 创建完整 slice。建议所有调用
进入聚合 counter，仅对超过阈值的慢调用创建 slice，并保留 mutation counter。

## 后台与前台语义

当前不假设 DPIS 进入后台后仍能准确完成所有采集工作。需要单独验证：

- DPIS UI 进程进入后台后，root shell/读取流程是否仍可靠；
- 目标进程通过 marker 是否仍能发现会话；
- `/data/local/tmp` 文件追加是否受 SELinux、进程权限或进程冻结影响；
- 返回 DPIS 时是否能稳定读取最后一个聚合快照；
- Perfetto stop 是否必须由 DPIS 前台进程触发；
- MIUI/HyperOS 是否对后台 DPIS 或目标进程执行冻结、延迟或省电限制。

因此导出必须包含独立的 transport health 和 capture completeness 字段，
不能把后台期间没有收到快照解释成“目标 route 没有命中”。

## 导出文件角色

`diagnostic.txt`：

- DiagnosticSession manifest
- ProcessEvidenceSession 列表
- route 安装/回调/decision/mutation 摘要
- 每进程性能聚合
- transport health
- Perfetto 文件引用
- CorrelationResult
- 未覆盖边界和证据不足说明

`timeline.tsv`：

- 按时间排序的结构化事件链；
- 字段包含 time、source、category、module、route、stage、process、package、message；
- 首期由已采集的 DPIS timeline、runtime transport 和 LSPosed 窗口解析结果生成；
- 用于回答“诊断期间哪些模块实际执行过、顺序是什么”，而不是只给最终摘要。

`module-effects.tsv`：

- 按进程与 route 聚合模块实际效果；
- 字段包含 source、process、pid、module、route、calls、applied、skipped、
  measuredCalls、p50Us、p95Us、p99Us、maxUs、note；
- 优先使用 LSPosed bridge 中的 target-process aggregate 聚合；
- transport 缺失时可从 LSPosed `mutation_applied` 事件生成
  `target-process-log-fallback`，但这种回退只代表命中和修改次数，
  不包含延迟分位数；
- 最后才使用 UI 进程 snapshot fallback，且必须标明它不能证明目标进程
  hook 实际执行。
- 如果诊断计划选择了某个模块，但窗口内没有观测到对应 route effect，
  必须输出 `source=diagnostic-plan` 的显式 0 行，例如
  `selected but no viewport route effect observed`。这表示证据缺口，不表示
  route 已执行或已修改。
- “观测到”包括结构化热路径事件的 `route=` / `routeName=`，不只是
  ProcessPerformance aggregate 里的 route 名。WeChat DPI 的
  `mutation_applied` 是 `route=wechat_dpi` 运行时事件，不会出现在 font
  aggregate 的 route 列表里；有这类事件时不得再输出
  `selected but no WeChat DPI route effect observed`。

`dpis-log.txt`：

- DPIS UI 进程应用日志；
- 不作为目标进程实际 hook 命中的唯一来源。

`lsposed-log.txt`：

- 原始 LSPosed 证据；
- 用于交叉验证模块加载、hook 安装和桥接日志。

Perfetto 原始文件：

- 当前不作为 ZIP entry，也不读入 Java 堆；
- 作为设备侧临时探针，由 `diagnostic.txt` 记录 available、size、truncated
  与失败原因；
- 如果采集失败，仍需导出失败原因和其它运行证据。

## 当前实现与目标模型的差距

当前分支已增加目标进程本地的
`ProcessPerformance`，并通过低频 LSPosed bridge 日志发布按
进程聚合的 calls/applied/skipped 与延迟分位数。导出端优先消费
`source=target-process-lsposed-aggregate` 的数据；旧的
`PerformanceSnapshot` 仍是迁移期间的 UI 进程 fallback，
不能作为目标 App 进程实际执行结果。

`Resources.getDisplayMetrics` 的覆盖计算在诊断会话进行时另记 body sample。
`calls` 是每次进入覆盖计算的次数，不是采样日志次数。耗时每次都会计入
`maxUs`，百分位只保留每 50 次中的 1 次，聚合字段是 `sampleStride=50`。
这样 4096 个样本能盖住整段滑动，而不是只盖住开头约两秒。没有诊断会话时
不记这组样本。稳定读的复用判断留在同一次计时里。命中时不再读 `getConfiguration`
和字体存储，只比较已返回的密度、像素宽高和写入侧代数。
解析入口用同一条比较，不再另建配置、字体和虚拟显示戳记。
复用命中的跳过日志在计时结束之后每 50 次记一条，命中路径不再为采样加锁或拼接字符串。

当前 `RuntimeTransport` 已经提供跨进程 marker 和文件通道，
并已开始承载目标进程周期性聚合快照。由于 appdomain 对
`/data/local/tmp` 的读取/追加可能受 SELinux 策略限制，活动 session 同时通过
`debug.dpis.diag.session` 广播短 session id；目标进程不能访问 marker 时可据此
恢复事件文件路径。由于部分 appdomain 不能可靠 append `/data/local/tmp`，聚合快照
现在以低频 `DPIS_DIAG_PERF` LSPosed 日志作为主目标进程证据，
导出端将其归类为 `source=runtime-hotpath category=performance`。
高频事件的 transport append 与 `DPIS_DIAG_HOTPATH` bridge 输出均在目标进程
内排队，由后台线程批量写入或交给 LSPosed sink；hook 回调线程不再同步执行
文件 I/O、`DpisLog` 回灌或 bridge sink。DPIS 收尾前会 flush 自己的 transport
队列，再读取事件文件。队列有界，溢出必须作为 transport completeness gap
报告，不能降级成“没有命中”。

## 未决问题

- Perfetto 预算超出约 60 秒时，是截断并继续等待返回，还是提前停止并标记
  `trace_budget_exhausted`。
- 系统是否允许目标进程自定义 trace section 直接写入 Perfetto。
- 慢调用阈值是否按 route 配置，还是先统一使用一个宽松阈值。
- `system_server` 的证据是否与 app-process 使用同一个 session id 和传输文件。
- 后台 DPIS/HyperOS 省电策略对 transport 和 Perfetto stop 的实际影响。
