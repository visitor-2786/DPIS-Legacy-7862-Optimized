# Android 10 Legacy CPU test2 build — 2026-10-17

This is a modified, unofficial DPIS 2.3.2 Legacy test candidate. GPL-3.0
licensing and the original notices remain applicable. No device performance
improvement is claimed without a device A/B run.

## Rebuild

Use JDK 21 (as pinned by gradle/gradle-daemon-jvm.properties), Gradle 9.7.1,
Android SDK API 37, build-tools 36.1.0, NDK 28.2.13676358 and CMake 3.22.1.
Point local.properties at your SDK, or set ANDROID_HOME.

Generate your own test certificate, then set DPIS_RELEASE_STORE_FILE,
DPIS_RELEASE_STORE_PASSWORD, DPIS_RELEASE_KEY_ALIAS and
DPIS_RELEASE_KEY_PASSWORD. Never use a production signing key for this test.

```
./gradlew :app:assembleLegacyRelease \
  -PDPIS_VERSION_NAME=2.3.2-legacy-cpu-test2 \
  -PDPIS_VERSION_CODE=20304
./gradlew :app:testLegacyDebugUnitTest \
  --tests '*LegacyModuleHookSourceTest' \
  --tests '*ResourcesMetricsReadReuseTest' \
  --tests '*ResourcesReadMetricsReuseTest'
```

The APK keeps the original application ID io.github.kwensiu.dpis so runtime
property/config ownership remains unchanged. Its certificate differs from
the upstream APK, but matches test1, allowing an in-place update from test1.
Export settings before uninstalling the upstream app; do
not expect an in-place update or side-by-side installation. Never enable two
DPIS variants against the same target.

## Changes and remaining risk

SDK 37 lint rejects the existing optional windowConfiguration reflection at
target SDK 36. Its method now explicitly suppresses BlockedPrivateApi because
this is injected-framework metadata; the reflection/null fallback is unchanged.

Legacy-only read hooks guard internal calls, retain resource identity, reuse
the existing metrics cache before expensive resolution, and explicitly retain
the configuration fallback on a miss. Configuration writes invalidate the
cache. Cache TTL is one second; live property changes can take that long.
ResourcesManager accepts the Android Q Locked suffix. API <30 skips the
unavailable WindowMetrics class. No root hiding or device settings change.

On-device installation, LSPosed loading, correct DPI, font/window transitions,
CPU, temperature, and jank still need verification on UIS7862S Android 10.

Test2 adds a full Configuration snapshot cache on Legacy getConfiguration and
the metrics miss fallback. It expires after 250ms without sliding the deadline,
checks resource/package/store/generation, and excludes configured font scaling.
Shared VirtualDisplayState no longer invalidates readers for identical display
and record publication. It still refreshes record timestamps and invalidates
all changed geometry/record semantics and explicit clears. The shared cache
invalidation behavior is regression-tested in both flavors. User feedback on
test1 was a large but incomplete reduction of jank; test2 is unverified on device.
