package com.dpis.module;

import com.dpis.module.updates.UpdateManifestFetcher;

import com.dpis.module.updates.StartupUpdateManifest;

import static org.junit.Assert.assertTrue;

import java.io.IOException;

import org.junit.Test;

public class UpdateManifestFetcherSourceSmokeTest {
    @Test
    public void manifestFetcherOwnsJsonParsingAndSharedHttpContract() throws IOException {
        String source = read("src/main/java/com/dpis/module/updates/UpdateManifestFetcher.java");

        assertTrue(source.contains("final class UpdateManifestFetcher"));
        assertTrue(source.contains("static StartupUpdateManifest fetch("));
        assertTrue(source.contains("connection.setRequestMethod(\"GET\")"));
        assertTrue(source.contains("connection.setRequestProperty(\"Accept\", \"application/json\")"));
        assertTrue(source.contains("new JSONObject(body)"));
        assertTrue(source.contains("private static String readUtf8("));
    }

    private static String read(String relativePath) throws IOException {
        return SourceSmokeTestPaths.read(relativePath);
    }
}
