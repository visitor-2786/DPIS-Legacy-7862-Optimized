package com.dpis.module.templates

import com.dpis.module.FakePrefs
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Protects the persisted catalog contract independently from the template editor UI. */
class QuickTemplateStoreBehaviorTest {
    @Test
    fun reorderKeepsKnownTemplatesOnceAndAppendsUnlistedTemplates() {
        val prefs = FakePrefs()
        val store = QuickTemplateStore(prefs)
        assertTrue(store.save(template("alpha", "Alpha", 1L)))
        assertTrue(store.save(template("beta", "Beta", 2L)))
        assertTrue(store.save(template("gamma", "Gamma", 3L)))

        assertTrue(store.reorder(listOf("beta", "missing", "beta")))

        assertEquals(
            listOf("beta", "alpha", "gamma"),
            store.readAll().map { it.id },
        )
        assertEquals("beta\nalpha\ngamma", prefs.getString(QuickTemplateStore.KEY_TEMPLATE_ORDER, null))
    }

    @Test
    fun reorderingAnEmptyCatalogClearsStaleOrderMetadata() {
        val prefs = FakePrefs()
        prefs.edit().putString(QuickTemplateStore.KEY_TEMPLATE_ORDER, "stale").commit()
        val store = QuickTemplateStore(prefs)

        assertTrue(store.reorder(emptyList()))

        assertNull(prefs.getString(QuickTemplateStore.KEY_TEMPLATE_ORDER, null))
        assertTrue(store.readAll().isEmpty())
    }

    @Test
    fun backupCopyIsIndependentFromLaterCallerMutationAndRestoresCatalog() {
        val source = QuickTemplateStore(FakePrefs())
        assertTrue(source.save(template("daily", "Daily", 5L, linkedSetOf("com.example.one"))))
        val backup = linkedMapOf<String, Any?>()

        source.copyToBackup(backup)
        @Suppress("UNCHECKED_CAST")
        (backup["template.daily.selected_packages"] as MutableSet<String>).add("com.example.mutated")

        assertEquals(setOf("com.example.one"), source.read("daily")!!.selectedPackages)
        val restored = QuickTemplateStore(FakePrefs())
        assertTrue(restored.restoreFromBackup(backup))
        assertEquals(
            setOf("com.example.one", "com.example.mutated"),
            restored.read("daily")!!.selectedPackages,
        )
    }

    @Test
    fun invalidIdentifiersNeverCreateOrMutateCatalogEntries() {
        val store = QuickTemplateStore(FakePrefs())

        assertFalse(store.save(template("invalid.id", "Invalid", 1L)))
        assertFalse(store.setSelectedPackages("invalid.id", linkedSetOf("com.example.one")))
        assertFalse(store.delete("invalid.id"))

        assertTrue(store.readAll().isEmpty())
    }

    @Test
    fun duplicateNamesRespectTheExcludedTemplate() {
        val store = QuickTemplateStore(FakePrefs())
        assertTrue(store.save(template("alpha", "  Shared name  ", 1L)))
        assertTrue(store.save(template("beta", "Other", 2L)))

        assertTrue(store.hasDuplicateName("shared name", null))
        assertFalse(store.hasDuplicateName("shared name", "alpha"))
        assertFalse(store.hasDuplicateName("missing", null))
    }

    @Test
    fun selectedPackagesAndDeleteUpdatePersistedTemplateState() {
        val store = QuickTemplateStore(FakePrefs())
        assertTrue(store.save(template("alpha", "Alpha", 1L)))

        assertTrue(store.setSelectedPackages("alpha", linkedSetOf("com.example.app")))
        assertEquals(setOf("com.example.app"), store.read("alpha")!!.selectedPackages)
        assertTrue(store.delete("alpha"))
        assertNull(store.read("alpha"))
        assertTrue(store.readAll().isEmpty())
    }

    @Test
    fun partialStoredOrderKeepsListedTemplatesFirstAndSortsRemainingTemplates() {
        val prefs = FakePrefs()
        val store = QuickTemplateStore(prefs)
        assertTrue(store.save(template("alpha", "Alpha", 1L)))
        assertTrue(store.save(template("beta", "Beta", 2L)))
        assertTrue(store.save(template("gamma", "Gamma", 3L)))
        prefs.edit().putString(QuickTemplateStore.KEY_TEMPLATE_ORDER, "beta").commit()

        assertEquals(
            listOf("beta", "gamma", "alpha"),
            store.readAll().map { it.id },
        )
    }

    @Test
    fun invalidOrBlankStoredTemplateEntriesAreHiddenWithoutChangingOtherTemplates() {
        val prefs = FakePrefs()
        val store = QuickTemplateStore(prefs)
        assertTrue(store.save(template("valid", "Valid", 1L)))
        prefs.edit()
            .putStringSet(QuickTemplateStore.KEY_TEMPLATE_IDS, linkedSetOf("valid", "blank"))
            .putString("template.blank.name", "   ")
            .putLong("template.blank.updated_at", 2L)
            .commit()

        assertNull(store.read("blank"))
        assertEquals(listOf("valid"), store.readAll().map { it.id })
    }

    @Test
    fun restoreBackupRejectsMissingCatalogWithoutErasingExistingTemplates() {
        val store = QuickTemplateStore(FakePrefs())
        assertTrue(store.save(template("daily", "Daily", 1L)))

        assertFalse(store.restoreBackup(null))
        assertEquals("Daily", store.read("daily")!!.name)
    }

    @Test
    fun restoreBackupRejectsNullEntriesAfterClearingCatalog() {
        val store = QuickTemplateStore(FakePrefs())
        assertTrue(store.save(template("daily", "Daily", 1L)))

        assertFalse(store.restoreBackup(mutableListOf(null)))
        assertTrue(store.readAll().isEmpty())
    }

    @Test
    fun backupHelpersIgnoreMissingEntriesAndGenerateUniqueIds() {
        val store = QuickTemplateStore(FakePrefs())
        val backup = linkedMapOf<String, Any?>()

        store.copyToBackup(null)
        store.copyToBackup(backup)

        assertTrue(backup.isEmpty())
        assertFalse(store.restoreFromBackup(null))
        assertFalse(store.restoreFromBackup(linkedMapOf("font.mode" to "off")))
        assertTrue(QuickTemplateStore.containsTemplateEntries(null).not())
        assertTrue(QuickTemplateStore.containsTemplateEntries(linkedMapOf("font.mode" to "off")).not())
        assertTrue(store.newTemplateId().isNotBlank())
    }

    @Test
    fun malformedPreferenceTypesUseSafeDefaultsAndInvalidOperationsAreRejected() {
        val prefs = FakePrefs()
        prefs.edit()
            .putStringSet(QuickTemplateStore.KEY_TEMPLATE_IDS, linkedSetOf("safe"))
            .putInt("template.safe.name", 7)
            .putString("template.safe.updated_at", "not-a-long")
            .putInt("template.safe.selected_packages", 7)
            .commit()
        val store = QuickTemplateStore(prefs)

        assertNull(store.read("safe"))
        assertFalse(store.save(null))
        assertFalse(store.setSelectedPackages(null, linkedSetOf("pkg")))
        assertFalse(store.setSelectedPackages("missing", linkedSetOf("pkg")))
        assertFalse(store.delete(null))
        assertTrue(store.reorder(null))
    }

    @Test
    fun saveNormalizesSelectedPackagesAndOrderMetadata() {
        val prefs = FakePrefs()
        val store = QuickTemplateStore(prefs)
        assertTrue(
            store.save(
                template(
                    "normalized",
                    "Name",
                    1L,
                    linkedSetOf(null, " ", " pkg ", "pkg"),
                ),
            ),
        )
        prefs.edit().putString(QuickTemplateStore.KEY_TEMPLATE_ORDER, "bad.id\n\nnormalized").commit()

        assertEquals(setOf("pkg"), store.read("normalized")!!.selectedPackages)
        assertEquals(listOf("normalized"), store.readAll().map { it.id })
    }

    private fun template(
        id: String,
        name: String,
        updatedAt: Long,
        selectedPackages: MutableSet<String?> = linkedSetOf(),
    ) = QuickTemplateStore.QuickTemplate(
        id,
        name,
        updatedAt,
        selectedPackages,
        TemplateConfigValue.EMPTY,
    )
}
