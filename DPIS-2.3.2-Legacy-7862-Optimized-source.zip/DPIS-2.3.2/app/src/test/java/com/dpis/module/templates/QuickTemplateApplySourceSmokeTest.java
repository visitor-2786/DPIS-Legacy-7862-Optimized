package com.dpis.module;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.io.IOException;
import com.dpis.module.config.DpisConfigStore;

public class QuickTemplateApplySourceSmokeTest {
    @Test
    public void templateWorkspaceCoordinatorOwnsApplyConfirmationAndResultCopy() throws IOException {
        String mainActivity = read("src/main/java/com/dpis/module/MainActivity.kt");
        String workspace = read("src/main/java/com/dpis/module/templates/presentation/TemplateWorkspaceCoordinator.kt");
        String coordinator = read(
                "src/main/java/com/dpis/module/templates/QuickTemplateApplyCoordinator.kt");
        String adapters = read("src/main/java/com/dpis/module/templates/QuickTemplateApplyAdapters.java");
        String strings = read("src/main/res/values/strings.xml");
        String zhStrings = read("src/main/res/values-zh-rCN/strings.xml");

        assertFalse(mainActivity.contains("private void applyQuickTemplate("));
        assertFalse(mainActivity.contains("finishQuickTemplateApply("));
        assertTrue(workspace.contains("fun applyQuickTemplate(templateId: String)"));
        assertTrue(workspace.contains("R.string.quick_template_apply_confirm_message"));
        assertTrue(workspace.contains("R.string.quick_template_apply_confirm_message_overwrite"));
        assertTrue(workspace.contains("QuickTemplateApplyConfirmationMessage.format("));
        assertTrue(workspace.contains("R.string.quick_template_apply_scope_note"));
        assertTrue(workspace.contains("finishQuickTemplateApply("));
        assertTrue(workspace.contains("TemplateWorkspacePresentation.ApplyConfirmation("));
        assertTrue(workspace.contains("pendingApply"));
        assertTrue(workspace.contains("confirmApply()"));
        String content = read("src/main/java/com/dpis/module/templates/presentation/TemplateWorkspaceContent.kt");
        assertTrue(content.contains("state.applyConfirmation"));
        assertTrue(content.contains("ConfirmAlertDialog("));
        assertTrue(workspace.contains("QuickTemplateApplyCoordinator<TemplateConfigValue>"));
        assertTrue(workspace.contains("QuickTemplateApplyAdapters.from(host.hookConfigStore())"));
        assertTrue(mainActivity.contains("val hookConfigStore: DpisConfigStore?"));
        assertTrue(mainActivity.contains("DpisApplication.getActiveHookConfigStore(this)"));
        assertTrue(workspace.contains("host.isInstalledTemplateTargetPackage"));
        String activityHost = read("src/main/java/com/dpis/module/templates/presentation/TemplateWorkspaceActivityHost.kt");
        assertTrue(activityHost.contains("packageManager.getApplicationInfo("));
        assertTrue(workspace.contains("R.string.quick_template_apply_result_success"));
        assertTrue(workspace.contains("R.string.quick_template_apply_result_partial"));
        assertTrue(coordinator.contains("interface ConfigWriter<T>"));
        assertTrue(coordinator.contains("interface RuntimePublisher<T>"));
        assertTrue(coordinator.contains("fun writePackageTemplateConfigValue("));
        assertFalse(coordinator.contains("DpisConfigStore"));
        assertFalse(coordinator.contains("PackageConfigRepository"));
        assertFalse(coordinator.contains("ViewportPropertySyncer"));
        assertTrue(adapters.contains("new PackageConfigRepository(store)"));
        assertTrue(adapters.contains("ViewportPropertySyncer.publishTargetAsync("));
        assertTrue(adapters.contains("ViewportPropertySyncer.clearTargetAsync("));
        assertTrue(adapters.contains("FontRuntimePropertySyncer.publishTargetAsync("));
        assertTrue(adapters.contains("FontRuntimePropertySyncer.clearFontScaleTargetAsync("));
        assertTrue(adapters.contains("FontRuntimePropertySyncer.publishTypefaceTargetAsync("));
        assertTrue(adapters.contains("FontHookDomainPropertySyncer.publishTargetAsync("));
        assertTrue(adapters.contains("FontHookDomainPropertySyncer.clearTargetAsync("));
        assertTrue(strings.contains("quick_template_apply_confirm_message_overwrite"));
        assertTrue(zhStrings.contains("quick_template_apply_confirm_message_overwrite"));
        assertFalse(coordinator.contains("executeProcessAction"));
        assertFalse(coordinator.contains("applyHyperOsNativeProxy"));
        assertFalse(coordinator.contains("unmountHyperOsNativeProxy"));
    }

    private static String read(String relativePath) throws IOException {
        return SourceSmokeTestPaths.read(relativePath);
    }
}
