package com.dpis.module;

import com.dpis.module.fonts.FontApplyMode;

import com.dpis.module.runtime.font.FontScaleOverride;

import android.util.TypedValue;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import com.dpis.module.config.DpisConfigStore;

public class FontScaleOverrideTest {
    @Test
    public void resolveFallsBackToOriginalWhenTargetMissing() {
        FakePrefs prefs = new FakePrefs();
        DpisConfigStore store = new DpisConfigStore(prefs);

        FontScaleOverride.Result result = FontScaleOverride.resolve(
                store, "com.max.xiaoheihe", 1.25f);

        assertEquals(1.25f, result.original, 0.0001f);
        assertEquals(1.25f, result.effective, 0.0001f);
        assertFalse(result.changed);
    }

    @Test
    public void resolveAppliesTargetPercentWhenConfigured() {
        FakePrefs prefs = new FakePrefs();
        prefs.edit().putInt("font.com.max.xiaoheihe.scale_percent", 150).commit();
        DpisConfigStore store = new DpisConfigStore(prefs);
        store.setSystemServerHooksEnabled(true);

        FontScaleOverride.Result result = FontScaleOverride.resolve(
                store, "com.max.xiaoheihe", 1.0f);

        assertEquals(Integer.valueOf(150), result.targetPercent);
        assertEquals(1.5f, result.effective, 0.0001f);
        assertTrue(result.changed);
    }

    @Test
    public void resolveAppliesFieldRewritePercentForResourcesFontDomain() {
        FakePrefs prefs = new FakePrefs();
        DpisConfigStore store = new DpisConfigStore(prefs);
        store.setSystemServerHooksEnabled(true);
        String packageName = "com.example.flutterapp";
        store.setTargetFontScalePercent(packageName, 300);
        store.setTargetFontApplyMode(packageName, FontApplyMode.FIELD_REWRITE);

        FontScaleOverride.Result result = FontScaleOverride.resolve(
                store, packageName, 1.0f);

        assertEquals(Integer.valueOf(300), result.targetPercent);
        assertEquals(3.0f, result.effective, 0.0001f);
        assertTrue(result.changed);
    }

    @Test
    public void resolveSkipsEmulationWhenSystemHookOff() {
        FakePrefs prefs = new FakePrefs();
        DpisConfigStore store = new DpisConfigStore(prefs);
        store.setSystemServerHooksEnabled(false);
        store.setTargetFontScalePercent("com.max.xiaoheihe", 150);
        store.setTargetFontApplyMode("com.max.xiaoheihe", FontApplyMode.SYSTEM_EMULATION);

        FontScaleOverride.Result result = FontScaleOverride.resolve(
                store, "com.max.xiaoheihe", 1.0f);

        assertEquals(1.0f, result.effective, 0.0001f);
        assertFalse(result.changed);
    }

    @Test
    public void identifiesUnitsThatNeedForceScaling() {
        assertTrue(FontScaleOverride.shouldForceTextUnit(TypedValue.COMPLEX_UNIT_PX));
        assertTrue(FontScaleOverride.shouldForceTextUnit(TypedValue.COMPLEX_UNIT_DIP));
        assertFalse(FontScaleOverride.shouldForceTextUnit(TypedValue.COMPLEX_UNIT_SP));
    }

}
