package com.dpis.module

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.w3c.dom.Element
import java.io.InputStream
import java.util.LinkedHashSet
import javax.xml.parsers.DocumentBuilderFactory
import com.dpis.module.settings.LocalizedActivity

class StringResourceParityTest {
    @Test
    fun localizedStringsExposeOnlyTranslatableNames() {
        val defaultNames = readStringNames("src/main/res/values/strings.xml", true)
        val defaultNonTranslatableNames = readStringNames("src/main/res/values/strings.xml", false)

        assertLocalizedStringNames(defaultNames, defaultNonTranslatableNames, "src/main/res/values-zh-rCN/strings.xml")
        assertLocalizedStringNamesAllowingFallback(defaultNames, defaultNonTranslatableNames, "src/main/res/values-ja-rJP/strings.xml")
        assertLocalizedStringNamesAllowingFallback(defaultNames, defaultNonTranslatableNames, "src/main/res/values-ru-rRU/strings.xml")
    }

    @Test
    fun defaultStringsAreEnglishFallback() {
        val defaultStrings = read("src/main/res/values/strings.xml")
        defaultStrings.assertContainsAll(
            "<string name=\"settings_language_label\">Language</string>",
            "<string name=\"module_description\">Per-app DPI &amp; text size</string>",
        )
        assertEquals("\u7b80\u4f53\u4e2d\u6587", readStringValue("src/main/res/values/strings.xml", "settings_language_simplified_chinese"))
        assertEquals("\u65e5\u672c\u8a9e\uff08\u672a\u6821\u6b63\uff09", readStringValue("src/main/res/values/strings.xml", "settings_language_japanese"))
        assertEquals("\u0420\u0443\u0441\u0441\u043a\u0438\u0439", readStringValue("src/main/res/values/strings.xml", "settings_language_russian"))
        assertEquals("\u8bed\u8a00", readStringValue("src/main/res/values-zh-rCN/strings.xml", "settings_language_label"))
    }

    @Test
    fun settingsScreenWiresLanguageSelector() {
        val content = read("src/main/java/com/dpis/module/settings/presentation/SettingsWorkspaceContent.kt")
        val source = read("src/main/java/com/dpis/module/settings/presentation/SystemServerSettingsPageController.kt")
        val dialogs = read("src/main/java/com/dpis/module/settings/presentation/SettingsComposeDialogs.kt")
        val dialogLayout = read("src/main/java/com/dpis/module/ui/dialog/DialogLayout.kt")
        val localeManager = read("src/main/java/com/dpis/module/settings/AppLocaleManager.kt")
        content.assertContainsAll("R.string.settings_language_label", "SettingsChoiceMenu(", "SettingsChoiceRow(")
        content.assertNotContainsAll("LanguageDialogContent(", "showLanguageDialog")
        dialogs.assertContainsAll("LanguageDialogContent(")
        assertTrue(dialogs.indexOf("dismiss()", dialogs.indexOf("onSelected = {")) >= 0)
        assertTrue(dialogs.indexOf("onSelected.accept(selectedTag)") > dialogs.indexOf("dismiss()", dialogs.indexOf("onSelected = {")))
        dialogLayout.assertContainsAll("DialogChrome.SurfacePadding", "LocalSpacing.current")
        source.assertContainsAll("showLanguageDialog", "AppLocaleManager.supportedLanguages()", "LanguageDialogOption(option.tag", "AppLocaleManager.setLanguageTag", "SettingsComposeDialogs.showLanguage", "AppLocaleManager.selectedLabelResId(activity)")
        source.assertNotContainsAll("settings_language_hint")
        localeManager.assertContainsAll("private val supportedLanguages = listOf(", "TAG_JAPANESE", "R.string.settings_language_japanese", "TAG_RUSSIAN", "R.string.settings_language_russian", "fun supportedLanguages(): List<LanguageOption>")
    }

    @Test
    fun languageSwitchDoesNotUseSavedInstanceStateForPersistedSwitches() {
        read("src/main/java/com/dpis/module/settings/presentation/SystemServerSettingsPageController.kt").assertNotContainsAll("STATE_HOOKS_SWITCH_CHECKED", "onSaveInstanceState", "restoreSwitchStates")
        read("src/main/java/com/dpis/module/settings/AppLocaleManager.kt").assertContainsAll("fun setLanguageTag", ".commit()")
    }

    @Test
    fun localeSwitchUsesWrappedBaseContextAndExplicitRecreate() {
        val settings = read("src/main/java/com/dpis/module/settings/presentation/SystemServerSettingsPageController.kt")
        val localized = read("src/main/java/com/dpis/module/settings/LocalizedActivity.kt")
        val localeManager = read("src/main/java/com/dpis/module/settings/AppLocaleManager.kt")
        val main = read("src/main/java/com/dpis/module/MainActivity.kt")
        val about = read("src/main/java/com/dpis/module/about/AboutActivity.kt")
        val license = read("src/main/java/com/dpis/module/about/OpenSourceLicenseActivity.kt")
        val fontLibrary = read("src/main/java/com/dpis/module/fonts/FontLibraryActivity.kt")
        val fontDetail = read("src/main/java/com/dpis/module/fonts/FontDetailActivity.kt")
        val manifest = read("src/main/AndroidManifest.xml")
        localized.assertContainsAll(": ComponentActivity()", "attachBaseContext(", "override fun onResume()", "AppLocaleManager.getLanguageTag(this)", "recreate()", "ThemeModeStore.getAppearance(this)", "PageSettingsStore.isPredictiveBackEnabled(this)", "legacySystemBack.isEnabled = !activePredictiveBackEnabled", "onUnhandledTaskRootBack()", "finish()")
        localized.assertNotContainsAll("moveTaskToBack(")
        localeManager.assertContainsAll("fun wrap(context: Context): Context", "createConfigurationContext(configuration)", "Context.MODE_PRIVATE", "Resources.getSystem().configuration.locales")
        main.assertContainsAll("LocalizedActivity()", "override fun onUnhandledTaskRootBack()", "moveTaskToBack(true)")
        read("src/main/java/com/dpis/module/ui/presentation/MainHostWiringSession.kt")
            .assertContainsAll("SettingsWorkspaceSession.create(")
        about.assertContainsAll(": LocalizedActivity()")
        license.assertContainsAll(": LocalizedActivity()")
        fontLibrary.assertContainsAll(": LocalizedActivity()")
        fontDetail.assertContainsAll(": LocalizedActivity()")
        manifest.assertContainsAll("android:supportsRtl=\"false\"")
        manifest.assertNotContainsAll("AppLocalesMetadataHolderService")
        settings.assertContainsAll("class SystemServerSettingsPageController(", "private val activity: LocalizedActivity")
    }

    private fun assertLocalizedStringNames(defaultNames: Set<String>, defaultsNonTranslatable: Set<String>, localizedPath: String) {
        val localizedNames = readStringNames(localizedPath)
        assertEquals(defaultNames, localizedNames)
        defaultsNonTranslatable.forEach { assertTrue(!localizedNames.contains(it)) }
    }

    private fun assertLocalizedStringNamesAllowingFallback(defaultNames: Set<String>, defaultsNonTranslatable: Set<String>, localizedPath: String) {
        val localizedNames = readStringNames(localizedPath)
        assertTrue(defaultNames.containsAll(localizedNames))
        defaultsNonTranslatable.forEach { assertTrue(!localizedNames.contains(it)) }
    }

    private fun readStringNames(relativePath: String, translatable: Boolean? = null): Set<String> {
        val factory = DocumentBuilderFactory.newInstance().apply { isIgnoringComments = true }
        SourceSmokeTestPaths.open(relativePath).use { input: InputStream ->
            val strings = factory.newDocumentBuilder().parse(input).getElementsByTagName("string")
            return LinkedHashSet<String>().apply {
                repeat(strings.length) { index ->
                    val element = strings.item(index) as Element
                    val isTranslatable = element.getAttribute("translatable") != "false"
                    if (translatable == null || translatable == isTranslatable) add(element.getAttribute("name"))
                }
            }
        }
    }

    private fun readStringValue(relativePath: String, name: String): String {
        val factory = DocumentBuilderFactory.newInstance().apply { isIgnoringComments = true }
        SourceSmokeTestPaths.open(relativePath).use { input ->
            val strings = factory.newDocumentBuilder().parse(input).getElementsByTagName("string")
            repeat(strings.length) { index ->
                val element = strings.item(index) as Element
                if (name == element.getAttribute("name")) return element.textContent
            }
        }
        error("Missing string resource: $name")
    }

    private fun read(relativePath: String) = SourceSmokeTestPaths.read(relativePath)
    private fun String.assertContainsAll(vararg needles: String) = needles.forEach { assertTrue("Missing $it", contains(it)) }
    private fun String.assertNotContainsAll(vararg needles: String) = needles.forEach { assertTrue("Unexpected $it", !contains(it)) }
}
