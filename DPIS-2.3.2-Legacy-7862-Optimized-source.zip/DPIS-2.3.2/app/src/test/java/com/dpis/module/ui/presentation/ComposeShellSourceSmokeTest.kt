package com.dpis.module

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File
import java.nio.charset.StandardCharsets
import java.nio.file.Files

/** Guards the stable Compose shell and workspace routing boundaries. */
class ComposeShellSourceSmokeTest {
    @Test
    fun composeThemeAndShellKeepTheRequiredBoundaries() {
        val theme = read("src/main/java/com/dpis/module/ui/presentation/design/ComposeDesignSystem.kt")
        val shell = read("src/main/java/com/dpis/module/ui/presentation/workspace/WorkspaceShell.kt")
        val adapter = read("src/main/java/com/dpis/module/ui/MainComposeWorkspaceAdapter.java")
        val mainShell = read("src/main/java/com/dpis/module/ui/MainComposeWorkspaceShell.kt")
        val coordinator = read("src/main/java/com/dpis/module/ui/presentation/MainWorkspacePresentationCoordinator.kt")

        // Keep this smoke test limited to stable ownership and routing contracts. Detailed
        // behavior belongs in executable tests, so internal layout names are intentionally not
        // asserted here.
        assertTrue(theme.contains("fun ComposeDesignSystem("))
        assertTrue(theme.contains("ColorSchemeFactory.create("))
        assertTrue(theme.contains("LocalSemanticColors provides"))
        val segmented = read(
            "src/main/java/com/dpis/module/ui/presentation/workspace/SegmentedListItemPolicy.kt",
        )
        val feedback = read(
            "src/main/java/com/dpis/module/ui/presentation/editor/FeedbackControls.kt",
        )
        assertTrue(segmented.contains("fun segmentedRowColors("))
        assertTrue(segmented.contains("MaterialTheme.colorScheme.surfaceBright"))
        assertTrue(feedback.contains("fun successButtonColors("))
        assertTrue(feedback.contains("fun warningButtonColors("))
        assertTrue(feedback.contains("fun outlinedWarningButtonColors("))
        assertTrue(feedback.contains("fun dangerButtonColors("))
        assertTrue(feedback.contains("LocalSemanticColors.current"))
        assertTrue(theme.contains("AppWindowBackground.update("))
        assertTrue(theme.contains("fun Activity.applyComposeWindowBackground("))
        assertFalse(theme.contains("AppTypography"))
        assertFalse(theme.contains("AppShapes"))
        assertFalse(theme.contains("setComposeContentAfterFirstDraw("))
        assertFalse(theme.contains("animateColorSchemeAsState"))
        val localized = read("src/main/java/com/dpis/module/settings/LocalizedActivity.kt")
        assertTrue(localized.contains("applyComposeWindowBackground()"))
        assertTrue(shell.contains("WorkspaceDestination"))
        assertTrue(shell.contains("onDestinationSelected"))
        assertTrue(adapter.contains("MainUiState.WorkspaceMode"))
        assertTrue(mainShell.contains("MainUiAction.workspaceModeChanged"))
        assertTrue(mainShell.contains("MainComposeWorkspaceAdapter.destinationFor(state.workspaceMode)"))
        assertTrue(mainShell.contains("BackHandler(enabled = homeDestination != null && selectedDestination != homeDestination)"))
        assertTrue(mainShell.contains("fun workspaceHomeDestination("))
        val startup = read(
            "src/main/java/com/dpis/module/ui/presentation/MainStartupSession.kt"
        )
        assertTrue(startup.contains("mainWorkspaceSession.installComposeWorkspaceShell()"))
        assertTrue(coordinator.contains("ComposeWorkspaceSurface"))
        assertTrue(coordinator.contains("TemplateWorkspaceContent"))
        val secondaryHost = read(
            "src/main/java/com/dpis/module/ui/presentation/SecondaryPageHost.kt"
        )
        val secondaryNavigator = read(
            "src/main/java/com/dpis/module/ui/presentation/SecondaryActivityNavigator.kt"
        )
        val mainShellHost = read(
            "src/main/java/com/dpis/module/ui/presentation/MainComposeShellHost.kt"
        )
        assertTrue(secondaryHost.contains("fun interface SecondaryNavigation"))
        assertTrue(secondaryNavigator.contains("class SecondaryActivityNavigator("))
        assertTrue(secondaryNavigator.contains("activity.startActivity(intentFor(destination))"))
        assertTrue(secondaryNavigator.contains("ThemeSettingsActivity::class.java"))
        assertTrue(secondaryNavigator.contains("FontDetailActivity.EXTRA_FONT_ID"))
        assertFalse(secondaryHost.contains("NavDisplay("))
        assertFalse(secondaryHost.contains("OverlayIdle"))
        assertFalse(secondaryHost.contains("AppUiScaleManager.wrap"))
        assertFalse(secondaryHost.contains("configurationEpoch"))
        assertTrue(mainShellHost.contains("ProvideSecondaryNavigation(secondaryNavigation)"))
        assertTrue(mainShellHost.contains("wrapInterfaceScaleContext(AppLocaleManager.wrap(activity))"))
        assertTrue(mainShellHost.contains("fun applyConfigurationInPlace()"))
        assertTrue(mainShellHost.contains("fun applyAppearanceInPlace()"))
        assertFalse(mainShellHost.contains("secondaryPages.Overlay()"))
        assertTrue(mainShellHost.contains("dynamicColor = appearance.dynamicColorEnabled"))
        assertTrue(mainShellHost.contains("themeColor = appearance.themeColor"))
        assertTrue(mainShellHost.contains("paletteStyle = appearance.paletteStyle"))
        assertTrue(mainShellHost.contains("colorSpecification = appearance.colorSpecification"))
    }

    @Test
    fun interfaceScaleSliderShowsOnlyEndpointMarkers() {
        val settings = read("src/main/java/com/dpis/module/settings/presentation/SettingsWorkspaceContent.kt")
        val theme = read("src/main/java/com/dpis/module/settings/presentation/ThemeSettingsContent.kt")
        val themeRows = read("src/main/java/com/dpis/module/settings/presentation/ThemeRows.kt")
        val home = read("src/main/java/com/dpis/module/home/presentation/HomeWorkspaceContent.kt")
        val tools = read("src/main/java/com/dpis/module/tools/presentation/ToolsWorkspaceContent.kt")

        assertTrue(themeRows.contains("steps = 0"))
        assertTrue(themeRows.contains("SliderDefaults.Track"))
        assertTrue(themeRows.contains("latestGestureValue.floatValue"))
        assertTrue(themeRows.contains("AppUiScaleManager.normalizeSliderPercent(changedValue)"))
        assertTrue(themeRows.contains("HapticFeedbackConstants.CLOCK_TICK"))
        assertTrue(theme.contains("style = MaterialTheme.typography.titleMedium"))
        assertFalse(settings.contains("SettingsScaleRow("))
        assertTrue(settings.contains("SettingsChoiceMenu("))
        assertTrue(settings.contains("SettingsChoiceRow("))
        assertTrue(settings.contains("selectedLanguageLabel"))
        assertFalse(settings.contains("LanguageDialogContent("))
        assertTrue(settings.contains("val systemContext = context.applicationContext"))
        assertTrue(settings.contains("it.tag == AppLocaleManager.TAG_FOLLOW_SYSTEM"))
        assertTrue(settings.contains(
                "enabled = state?.storeAvailable == true && state.cacheClearInProgress != true"))
        assertTrue(home.contains("rememberClickAction"))
        assertTrue(home.contains(".clip(CircleShape)"))
        assertTrue(home.contains("PageBarBehavior.Collapsing"))
        assertTrue(home.contains("ToolbarIconButton("))
        assertTrue(home.contains("titleRes = R.string.app_name"))
        assertFalse(home.contains("subtitle = {"))
        assertFalse(home.contains("home_workspace_subtitle"))
        assertTrue(home.contains("bodyInsets = padding"))
        assertTrue(tools.contains("rememberClickAction"))
        assertTrue(tools.contains("SystemFontScaleBadge(state)"))
        assertTrue(tools.contains("if (!state.canWrite && !state.unavailable)"))
        assertTrue(tools.contains("else if (state.unavailable)"))
        assertTrue(tools.contains("state.canDecrement()"))
        assertTrue(tools.contains("state.canRestore()"))
        assertTrue(tools.contains("SystemFontScaleToolState.normalizeSliderPercent(it)"))
        assertTrue(tools.contains("LocalDensity provides Density(displayDensity.density, fontScale = 1f)"))
        assertTrue(tools.contains("PageBarBehavior.Collapsing"))
        assertTrue(tools.contains("bodyInsets = padding"))
        assertTrue(tools.contains("listState = listState"))
        assertFalse(tools.contains("TopAppBar("))
        assertTrue(settings.contains("PageBarBehavior.Collapsing"))
        assertTrue(settings.contains("bodyInsets = padding"))
        assertTrue(home.contains("bodyInsets = padding"))
        assertFalse(settings.contains("TopAppBar("))
        assertTrue(home.contains("rememberClickAction"))
    }

    @Test
    fun standaloneSettingsPagesUseSharedSecondaryPageChrome() {
        val scaffold = read("src/main/java/com/dpis/module/ui/presentation/workspace/PageScaffold.kt")
        val topBar = read("src/main/java/com/dpis/module/ui/presentation/workspace/PageTopBar.kt")
        val toolbar = read("src/main/java/com/dpis/module/ui/presentation/workspace/ToolbarActions.kt")
        val theme = read("src/main/java/com/dpis/module/settings/presentation/ThemeSettingsContent.kt")
        val experimental = read(
                "src/main/java/com/dpis/module/settings/presentation/ExperimentalSettingsContent.kt")

        assertTrue(scaffold.contains("internal fun SecondaryPageScaffold("))
        assertFalse(scaffold.contains("internal fun PrimaryPageScaffold("))
        assertTrue(scaffold.contains("startCollapsed = true"))
        assertTrue(scaffold.contains("startCollapsed: Boolean = false"))
        assertTrue(scaffold.contains("initialHeightOffsetLimit = if (collapsedInitially) collapsedOffsetPx else -Float.MAX_VALUE"))
        assertTrue(scaffold.contains("initialHeightOffset = collapsedOffsetPx"))
        assertTrue(scaffold.contains("LargeFlexibleAppBarWithoutSubtitleExpandedHeight"))
        assertFalse(scaffold.contains("deferBodyUntilFirstFrame"))
        assertFalse(scaffold.contains("withFrameNanos"))
        assertFalse(scaffold.contains("topAppBarState.heightOffset = topAppBarState.heightOffsetLimit"))
        assertTrue(scaffold.contains("contentColor = MaterialTheme.colorScheme.onSurface"))
        assertTrue(topBar.contains("internal fun CollapsingPageTopBar("))
        assertTrue(topBar.contains("LargeFlexibleTopAppBar("))
        assertTrue(topBar.contains("pageExpandedSubtitleStyle()"))
        assertTrue(topBar.contains("pageCompactTitleStyle()"))
        assertTrue(topBar.contains("pageTitleStart()"))
        assertTrue(topBar.contains("startInset = !includeHorizontalSafeInsets"))
        assertTrue(topBar.contains("pageTopBarWindowInsets(includeHorizontalSafeInsets)"))
        assertTrue(topBar.contains("Spacer(Modifier.size(PageChromeTokens.ContentInset))"))
        assertTrue(scaffold.contains("pageHorizontalSafePadding(onBack != null)"))
        assertTrue(topBar.contains("internal fun SplitPaneHeader("))
        assertTrue(topBar.contains("PageChromeTokens.CompactSlotHeight"))
        assertTrue(scaffold.contains("PageChromeTokens.ContentInset"))
        assertTrue(scaffold.contains("PageChromeTokens.ItemSpacing"))
        assertFalse(topBar.contains("drawEdgeOcclusionFade("))
        assertTrue(scaffold.contains("exitUntilCollapsedScrollBehavior("))
        assertTrue(scaffold.contains("nestedScroll(scrollBehavior.nestedScrollConnection)"))
        assertTrue(scaffold.contains("modifier = if (collapsing)"))
        assertFalse(scaffold.contains("CollapsingBarBodyScrollConnection"))
        assertFalse(scaffold.contains("PAGE_EXPANDED_TITLE_KEY"))
        assertFalse(scaffold.contains("PageCollapseScrollConnection"))
        assertFalse(theme.contains("pageExpandedTitle()"))
        assertFalse(theme.contains("rememberPageListState()"))
        assertFalse(topBar.contains("fontSize = 34.sp"))
        assertTrue(topBar.contains("internal fun InFlowPageHeader("))
        val appWorkspace = read("src/main/java/com/dpis/module/applist/presentation/AppListContent.kt")
        val templateWorkspace = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateWorkspaceContent.kt")
        assertFalse(appWorkspace.contains("SplitPaneHeader("))
        assertTrue(appWorkspace.contains("PageChromeTokens.SearchCardHeight"))
        assertTrue(appWorkspace.contains("extraTopPadding = topSafePadding"))
        assertFalse(templateWorkspace.contains("SplitPaneHeader("))
        assertTrue(templateWorkspace.contains("topSafePadding = topSafePadding"))
        assertTrue(read(
                "src/main/java/com/dpis/module/templates/presentation/QuickTemplateTargetsContent.kt")
            .contains("SplitPaneHeader("))
        assertTrue(toolbar.contains("internal fun ToolbarIconButton("))
        assertTrue(toolbar.contains("internal fun ToolbarOverflowMenu("))
        assertTrue(toolbar.contains("internal fun ToolbarOverflowMenuGroup("))
        assertTrue(theme.contains("SecondaryPageScaffold("))
        assertTrue(experimental.contains("SecondaryPageScaffold("))
        assertFalse(theme.contains("TopAppBar("))
        assertFalse(experimental.contains("CenterAlignedTopAppBar("))
    }

    @Test
    fun themeSettingsExpandsStaticColorOptionsWhenDynamicColorIsDisabled() {
        val theme = read("src/main/java/com/dpis/module/settings/presentation/ThemeSettingsContent.kt")
        val themeRows = read("src/main/java/com/dpis/module/settings/presentation/ThemeRows.kt")
        val host = read("src/main/java/com/dpis/module/settings/presentation/ThemeHost.kt")
        val settings = read("src/main/java/com/dpis/module/settings/presentation/SettingsWorkspaceContent.kt")
        val choiceMenu = read("src/main/java/com/dpis/module/settings/presentation/SettingsChoiceMenu.kt")
        val colors = read("src/main/java/com/dpis/module/ui/presentation/design/ComposeDesignSystem.kt")

        assertTrue(theme.contains("ThemeDynamicColorRow("))
        assertTrue(theme.contains("AnimatedConditionalItem(visible = !dynamicColorEnabled)"))
        assertTrue(themeRows.contains("R.string.settings_theme_color_label"))
        assertTrue(theme.contains("R.string.settings_theme_palette_style_label"))
        assertTrue(theme.contains("R.string.settings_theme_color_spec_label"))
        assertTrue(themeRows.contains("ThemeColorOption(ThemeModeStore.DEFAULT_STATIC_THEME_COLOR)"))
        assertTrue(themeRows.contains("ThemeSwatchPreviewCache.prefetch("))
        assertTrue(themeRows.contains("ThemeSwatchPreviewCache.peek("))
        assertFalse(themeRows.contains("ThemeSwatchPreviewCache.get("))
        assertTrue(settings.contains("ThemeSwatchPreviewCache.prefetch("))
        assertTrue(theme.contains("ThemeChoiceMenuAnchor("))
        assertTrue(themeRows.contains("SettingsChoiceMenu("))
        assertTrue(choiceMenu.contains("DropdownMenuPopup("))
        assertTrue(choiceMenu.contains("SelectableDropdownMenuItem("))
        assertTrue(choiceMenu.contains("MenuDefaults.itemShape(index, options.size)"))
        assertTrue(choiceMenu.contains("containerColor = Color.Transparent"))
        assertTrue(choiceMenu.contains("disabledContainerColor = Color.Transparent"))
        assertFalse(choiceMenu.contains("selectedContainerColor"))
        assertTrue(choiceMenu.contains(".widthIn(max = 360.dp)"))
        assertTrue(choiceMenu.contains("shape = MaterialTheme.shapes.large"))
        assertFalse(choiceMenu.contains(".clip(MaterialTheme.shapes.large)"))
        assertFalse(choiceMenu.contains("import androidx.compose.material3.DropdownMenuItem"))
        assertTrue(choiceMenu.contains("rememberClickValueAction(onSelected)"))
        assertTrue(choiceMenu.contains("Box(Modifier.align(Alignment.BottomEnd))"))
        assertFalse(choiceMenu.contains("trailingIcon = if (selected == value)"))
        assertFalse(theme.contains("ThemeChoiceDialog("))
        assertFalse(theme.contains("ThemeModeDialog("))
        assertFalse(themeRows.contains("ThemeColorOption(\"default\")"))
        assertTrue(themeRows.contains("internal fun ThemeSegmentedSurfaceRow("))
        assertTrue(theme.contains("ThemePredictiveBackRow("))
        assertTrue(theme.contains("DpisSwitch("))
        assertFalse(theme.contains("import androidx.compose.material3.Switch"))
        assertTrue(themeRows.contains("R.string.settings_page_predictive_back"))
        assertTrue(theme.contains("R.string.settings_theme_section_page"))
        assertTrue(theme.contains("val pageItemCount = if (predictiveBackAvailable) 3 else 2"))
        assertTrue(host.contains("PageSettingsStore.setPredictiveBackEnabled("))
        assertTrue(themeRows.contains("SegmentedListItem("))
        assertTrue(themeRows.contains("shapes = dpisSegmentedShapes(index, total)"))
        assertTrue(themeRows.contains("rememberSegmentedPressedShape("))
        assertTrue(host.contains("ThemeModeStore.setDynamicColorEnabled(context, enabled)"))
        assertTrue(host.contains("dynamicColorEnabled = enabled"))
        assertTrue(host.contains("var mode by remember"))
        assertTrue(host.contains("fun ThemeSettingsRoute("))
        assertTrue(host.contains("ThemeModeStore.resolveDarkTheme(mode, isSystemInDarkTheme())"))
        assertTrue(host.contains("markAppearanceAppliedInPlace()"))
        assertFalse(
            host.substringAfter("val applyMode")
                .substringBefore("val applyDynamicColor")
                .contains("recreate()"),
        )
        assertTrue(colors.contains("ThemeModeStore.isDynamicColorEnabled(context)"))
    }

    @Test
    fun templateEditorUsesExpandedModalStateAndObservesDraftRevision() {
        val workspace = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateWorkspaceContent.kt")
        val editor = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateEditorContent.kt")
        val templateSheet = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateEditorSheet.kt")

        assertTrue(workspace.contains(
                "TemplateEditorSurface("))
        assertFalse(workspace.contains("TemplateEditorSurfaceKind"))
        assertTrue(workspace.contains("val draftRevision = editorDraft.observe()"))
        assertTrue(workspace.contains("draftRevision = draftRevision"))
        assertTrue(editor.contains("draftRevision: Int"))
        assertFalse(editor.contains("remember(draftRevision) { Unit }"))
        assertFalse(editor.contains("AppConfigEditorOverlay("))
        assertFalse(editor.contains("SheetVisualChrome("))
        assertTrue(editor.contains("destination = destination"))
        assertTrue(editor.contains("animateSize = animateDestinationSize"))
        assertTrue(editor.contains("edgeToEdgeContentBottomPadding("))
        assertTrue(workspace.contains("TemplateEditorSheet("))
        assertFalse(workspace.contains("rememberStandardBottomSheetState("))
        assertFalse(editor.contains("BottomSheetScaffold("))
        assertTrue(templateSheet.contains("rememberStandardBottomSheetState("))
        assertTrue(templateSheet.contains("EditorSheetScaffoldFrame("))
        assertTrue(templateSheet.contains("bottomSheetState.partialExpand()"))
        assertTrue(templateSheet.contains(
                "destination.isChildPage() && !sheetMotionInProgress"))
        val editorSheetBody = workspace.substringAfter("val editorSheetBody")
                .substringBefore("\n    Box(")
        assertFalse(editorSheetBody.contains("topSafePadding"))
        assertFalse(templateSheet.contains("AppConfigEditorOverlay("))
        assertFalse(templateSheet.contains("EditorBottomSheet("))
    }

    @Test
    fun mainShellDisplaysPrefillChipFromEditorSession() {
        val shell = read("src/main/java/com/dpis/module/ui/presentation/MainWorkspacePresentationCoordinator.kt")

        // Compose shell wiring requires an Android runtime; the session chip behavior is covered by AppConfigEditorSessionTest.
        assertTrue(shell.contains("editorState.chip != AppConfigEditorChip.NONE"))
    }

    @Test
    fun templateWorkspaceKeepsTheLegacySearchAndHeaderActionSemantics() {
        val template = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateWorkspaceList.kt")
        val emptyCopy = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateListEmptyCopy.kt")
        val tokens = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateUiTokens.kt")
        val search = read(
                "src/main/java/com/dpis/module/ui/presentation/workspace/WorkspaceSearchCard.kt")

        assertTrue(template.contains("WorkspaceSearchCard("))
        assertTrue(template.contains("hintRes = R.string.template_search_hint"))
        assertTrue(template.contains("onQueryChanged = onQueryChanged"))
        assertTrue(template.contains("rememberRestorableLazyListState("))
        assertTrue(search.contains("cursorBrush = SolidColor(MaterialTheme.colorScheme.primary)"))
        assertTrue(search.contains("R.drawable.ic_close_24"))
        assertTrue(template.contains("role = Role.Button"))
        assertTrue(template.contains("TemplateUiTokens.DISABLED_ACTION_ALPHA"))
        assertTrue(template.contains("TemplateUiTokens.EmptySummaryTopGap"))
        assertTrue(template.contains("TemplateUiTokens.CardActionVisualSize"))
        assertTrue(template.contains("TemplateApplyAction("))
        assertTrue(template.contains("R.drawable.ic_done_all_24"))
        assertTrue(template.contains("R.string.template_workspace_action_apply"))
        assertTrue(template.contains("TemplateActionButtonStyle.Plain"))
        assertTrue(template.contains("TemplateActionButtonStyle.Primary"))
        assertFalse(template.contains("SearchCardBorderWidth"))
        assertTrue(template.contains("TemplateListEmptyCopy(searching = state.searching)"))
        assertTrue(emptyCopy.contains("R.string.quick_template_search_empty"))
        assertTrue(emptyCopy.contains("contentAlignment = Alignment.Center"))
        assertTrue(emptyCopy.contains("Modifier.fillParentMaxSize()"))
        assertFalse(emptyCopy.contains("Alignment.CenterStart"))
        assertTrue(tokens.contains("PageChromeTokens.SearchCardHeight"))
        assertTrue(tokens.contains("val WorkspaceTopPadding = 14.dp"))
        assertTrue(tokens.contains("val SectionTitleInset = PageChromeTokens.TitleInset"))
        assertTrue(tokens.contains("val SectionActionInset = PageChromeTokens.TitleInset"))
        assertTrue(tokens.contains("val HeaderActionVisualSize = 36.dp"))
        assertTrue(tokens.contains("val CardActionVisualSize = 28.dp"))
        assertTrue(tokens.contains("val ApplyActionVisualSize = CardActionVisualSize"))
        assertTrue(tokens.contains("const val DISABLED_ACTION_ALPHA = 0.45f"))
    }

    @Test
    fun templateEditorKeepsValidationFromChangingItsMeasuredHeight() {
        val editor = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateEditorContent.kt")
        val appEditor = read(
                "src/main/java/com/dpis/module/appconfig/presentation/AppConfigEditorContent.kt")
        val controls = read(
                "src/main/java/com/dpis/module/ui/presentation/editor/EditorControls.kt")

        assertTrue(editor.contains("val viewportHasError = !form.isViewportInputValid()"))
        assertTrue(editor.contains("isError = viewportHasError"))
        assertTrue(editor.contains("isError = fontHasError"))
        assertFalse(editor.contains("TemplateEditorErrorMessage"))
        assertFalse(appEditor.contains("EditorInputError"))
        assertTrue(controls.contains("rememberEditorControlHeight()"))
        assertTrue(controls.contains("coerceAtLeast(AppConfigSheetUiTokens.ActionHeight)"))
        assertTrue(controls.contains("color = MaterialTheme.colorScheme.onSurface"))
        assertTrue(controls.contains("cursorBrush = SolidColor(MaterialTheme.colorScheme.primary)"))
        assertTrue(controls.contains(".textInputFocusBehavior(onFocused)"))
        val haptics = read("src/main/java/com/dpis/module/ui/presentation/design/ComposeHaptics.kt")
        assertTrue(haptics.contains("fun Modifier.inputFocusFeedback("))
        assertTrue(haptics.contains("focusState.isFocused && !wasFocused"))
        assertTrue(haptics.contains("confirmFocus()"))
        assertTrue(editor.contains("val hookDomainsButtonText = FontHookDomainPresentation"))
        assertTrue(editor.contains("forAutomaticDomainsRaw(form.fontHookDomainsRaw)"))
        assertTrue(editor.contains(".buttonText(context)"))
        assertFalse(editor.contains("dialog_font_hook_domains_title_with_count, 1, 1"))
    }

    @Test
    fun composeAppEditorRestoreDoesNotOpenLegacySheet() {
        val workspace = read(
            "src/main/java/com/dpis/module/ui/presentation/MainWorkspaceSession.kt"
        )
        val restoreStart = workspace.indexOf(
            "fun restoreAppEditorForCurrentWorkspace()"
        )
        val restoreEnd = workspace.indexOf(
            "fun bindForLifecycle(", restoreStart
        )
        val restore = workspace.substring(restoreStart, restoreEnd)

        assertTrue(restore.contains("composeShellHost?.refreshApps()"))
        assertFalse(restore.contains("activity.sheetSession.show(appItem)"))
        assertFalse(restore.contains("activity.landDetailSession.show(appItem)"))
    }

    @Test
    fun composeAppSheetPreservesPartialExpandAndLegacyChromeSemantics() {
        val sheet = read("src/main/java/com/dpis/module/ui/presentation/editor/EditorBottomSheet.kt")
        val coordinator = read(
                "src/main/java/com/dpis/module/ui/presentation/MainWorkspacePresentationCoordinator.kt")
        val overlay = read("src/main/java/com/dpis/module/appconfig/presentation/AppConfigEditorOverlay.kt")
        val sheetFrame = read(
                "src/main/java/com/dpis/module/ui/presentation/editor/EditorSheetScaffoldFrame.kt")
        val appEditor = read(
                "src/main/java/com/dpis/module/appconfig/presentation/AppConfigEditorContent.kt")
        val appWorkspace = read(
                "src/main/java/com/dpis/module/applist/presentation/AppListContent.kt")
        val controls = read(
                "src/main/java/com/dpis/module/ui/presentation/editor/EditorControls.kt")
        val catalog = read(
                "src/main/java/com/dpis/module/applist/presentation/InstalledAppCatalogCoordinator.kt")
        val typefacePicker = read(
                "src/main/java/com/dpis/module/appconfig/presentation/AppTypefacePickerPage.kt")
        val activity = read("src/main/java/com/dpis/module/MainActivity.kt")
        val editorController = read(
                "src/main/java/com/dpis/module/appconfig/editor/EditorActions.kt")
        val editorSessionController = read(
                "src/main/java/com/dpis/module/appconfig/editor/ComposeAppEditorController.kt")

        assertTrue(sheet.contains("ModalBottomSheet("))
        assertTrue(sheet.contains("openPartiallyExpanded: Boolean = false"))
        assertTrue(overlay.contains("fun AppConfigEditorOverlay("))
        assertTrue(coordinator.contains("AppConfigWizardStore.shouldShowAdvancedHint(context)"))
        assertTrue(coordinator.contains("AppConfigEditorOverlay("))
        assertTrue(coordinator.contains("RenderAppEditorOverlay(mode: MainUiState.WorkspaceMode, wear: Boolean = false)"))
        assertTrue(coordinator.contains("WearAppConfigEditorContent(it)"))
        assertTrue(coordinator.contains("appRevision"))
        assertTrue(coordinator.contains("if (mode != MainUiState.WorkspaceMode.APP) return"))
        assertTrue(coordinator.contains(
                "configuration.orientation == Configuration.ORIENTATION_LANDSCAPE"))
        assertTrue(coordinator.contains("if (twoPane) return@BoxWithConstraints"))
        assertTrue(overlay.contains("rememberBottomSheetScaffoldState("))
        assertTrue(overlay.contains("EditorSheetScaffoldFrame("))
        assertTrue(overlay.contains("bottomSheetState.hide()"))
        assertTrue(coordinator.contains("AppConfigWizardHint("))
        val wizardHint = read(
                "src/main/java/com/dpis/module/appconfig/presentation/AppConfigWizardHint.kt")
        assertTrue(wizardHint.contains("R.string.dialog_advanced_wizard_hint"))
        assertTrue(wizardHint.contains("Canvas("))
        assertTrue(wizardHint.contains("wizardHintSurface()"))
        assertTrue(wizardHint.contains("color = hintSurface"))
        assertFalse(wizardHint.contains("bg_app_config_wizard_arrow"))
        assertTrue(coordinator.contains("R.string.feedback_diagnostic_action"))
        assertTrue(coordinator.contains("AppConfigSheetUiTokens.TopChromeIndicatorWidth"))
        assertTrue(coordinator.contains("editorState.chip != AppConfigEditorChip.NONE"))
        assertTrue(coordinator.contains("AppConfigEditorSessionChip("))
        val chip = read("src/main/java/com/dpis/module/appconfig/presentation/AppConfigEditorContent.kt")
        assertTrue(chip.contains("MaterialTheme.colorScheme.secondaryContainer"))
        assertTrue(chip.contains("MaterialTheme.colorScheme.onSecondaryContainer"))
        assertTrue(chip.contains("MaterialTheme.colorScheme.secondary"))
        assertTrue(chip.contains("dangerButtonColors()"))
        assertTrue(chip.contains("warningButtonColors()"))
        assertTrue(chip.contains("successButtonColors()"))
        assertFalse(chip.contains("R.color.dpis_"))
        assertTrue(coordinator.contains("showInlineUnsavedBadge = false"))
        assertTrue(appEditor.contains("showInlineUnsavedBadge: Boolean = true"))
        assertTrue(appEditor.contains("coordinates.positionInParent().y.toDp()"))
        assertTrue(appEditor.contains(
                "padding(bottom = edgeToEdgeContentBottomPadding(0.dp))"))
        assertFalse(appEditor.contains("navigationBarsPadding()"))
        assertTrue(appWorkspace.contains("VerticalDivider("))
        assertFalse(appWorkspace.contains("alwaysFloatInputLabels"))
        assertTrue(controls.contains("label: String"))
        assertTrue(controls.contains("maxLines = 1"))
        assertTrue(controls.contains("softWrap = false"))
        assertTrue(controls.contains("overflow = TextOverflow.Ellipsis"))
        assertTrue(appEditor.contains("rememberInstalledAppIcon"))
        assertTrue(appEditor.contains("AppConfigSheetUiTokens.ContentPadding"))
        assertTrue(appEditor.contains("val focusManager = LocalFocusManager.current"))
        assertTrue(appEditor.contains("focusManager.clearFocus(force = true)"))
        assertTrue(sheetFrame.contains(
                ".clearTextInputFocusOutside(focusManager, inputFocusBoundary)"))
        assertTrue(sheetFrame.contains("sheetSwipeEnabled = sheetSwipeEnabled"))
        assertFalse(appEditor.contains(".clearTextInputFocusOutside(focusManager, inputFocusBoundary)"))
        assertTrue(appEditor.contains(".reportTextInputFocusBounds(inputFocusBoundary, \"viewport\")"))
        assertTrue(appEditor.contains(".reportTextInputFocusBounds(inputFocusBoundary, \"font\")"))
        val typefaceLibraryOpen = typefacePicker.indexOf(
                "secondaryNavigation?.open(SecondaryDestination.FontLibrary)")
        assertTrue(typefaceLibraryOpen > 0)
        assertTrue(typefacePicker.substring(0, typefaceLibraryOpen).contains("onBack()"))
        assertTrue(typefacePicker.contains("fun AppTypefacePickerPage("))
        assertFalse(typefacePicker.contains("Dialog("))
        assertTrue(typefacePicker.contains("TypefacePickerUiTokens.TypefaceOptionHeight"))
        assertTrue(typefacePicker.contains("TypefaceCatalogCache.Catalog"))
        assertTrue(typefacePicker.contains("TypefaceCatalogCache.cached()"))
        assertTrue(typefacePicker.contains("withContext(Dispatchers.IO)"))
        assertTrue(typefacePicker.contains(".fillMaxSize()"))
        assertTrue(typefacePicker.contains("dialogListContentFade("))
        assertTrue(typefacePicker.contains("EditorSheetChildPageHeader("))
        assertTrue(typefacePicker.contains("containerColor = MaterialTheme.colorScheme.surfaceContainer"))
        assertTrue(typefacePicker.contains("MaterialTheme.colorScheme.surfaceBright"))
        assertTrue(sheet.contains("internal fun EditorSheetChildPageHeader("))
        assertTrue(sheet.contains("ChildPageHeaderHeight"))
        assertTrue(editorSessionController.contains("EditorActions.create("))
        assertTrue(
            read(
                "src/main/java/com/dpis/module/ui/presentation/MainStartupSession.kt"
            ).contains("fun requestAppsLoad()")
        )
        assertTrue(editorController.contains("host.setDpisEnabled(enabled)"))
        assertTrue(editorController.contains("draft.withDpisEnabled(enabled)"))
    }

    @Test
    fun hookChainIsARecoverableChildPageOfBothEditorSessions() {
        val page = read("src/main/java/com/dpis/module/fonts/presentation/HookChainEditorPage.kt")
        val destination = read("src/main/java/com/dpis/module/ui/ConfigEditorDestination.java")
        val appEditor = read(
                "src/main/java/com/dpis/module/appconfig/presentation/AppConfigEditorContent.kt")
        val appWorkspace = read(
                "src/main/java/com/dpis/module/applist/presentation/AppListContent.kt")
        val coordinator = read(
                "src/main/java/com/dpis/module/ui/presentation/MainWorkspacePresentationCoordinator.kt")
        val viewModel = read("src/main/java/com/dpis/module/ui/MainViewModel.kt")
        val activity = read("src/main/java/com/dpis/module/MainActivity.kt")
        val templates = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateWorkspaceContent.kt")
        val templatePresentation = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateWorkspacePresentation.kt")

        assertTrue(page.contains("fun HookChainEditorPage("))
        assertTrue(page.contains("HookChainPageTokens.RiskLow"))
        assertTrue(page.contains("hookDomainStatusColor("))
        assertFalse(page.contains("R.color.font_hook_domain_risk"))
        assertTrue(page.contains("BackHandler(onBack = onBack)"))
        assertTrue(page.contains("RadioButton("))
        assertTrue(page.contains("SegmentedListItem("))
        assertTrue(page.contains(".clip(shapes.shape)"))
        assertTrue(page.contains("FeedbackSwitch("))
        assertTrue(page.contains("val selectDestination = rememberClickValueAction"))
        assertTrue(page.contains("val selectMode = rememberClickValueAction(onModeSelected)"))
        assertFalse(page.contains("Dialog("))
        assertFalse(page.contains("Scaffold("))
        assertTrue(page.contains("fun ConfigEditorAnimatedContent("))
        assertTrue(page.contains("SheetDestinationAnimatedContent("))
        assertTrue(page.contains("clipContentToAnimatedBounds"))
        val sheetDestination = read(
            "src/main/java/com/dpis/module/ui/presentation/editor/SheetDestinationAnimatedContent.kt",
        )
        val motion = read("src/main/java/com/dpis/module/ui/presentation/design/Motion.kt")
        assertTrue(sheetDestination.contains("slideInHorizontally("))
        assertTrue(sheetDestination.contains("if (animateSize)"))
        assertTrue(sheetDestination.contains("Modifier.zIndex"))
        assertTrue(sheetDestination.contains("clipToBounds()"))
        assertTrue(sheetDestination.contains("SizeTransform("))
        assertTrue(sheetDestination.contains("clip = false"))
        assertTrue(motion.contains("SHEET_DESTINATION_HEIGHT_DURATION_MILLIS = 180"))
        assertTrue(page.contains(".fillMaxHeight()"))
        assertTrue(page.contains("EditorSheetChildPageHeader("))
        assertTrue(page.contains("containerColor = MaterialTheme.colorScheme.surfaceContainer"))
        assertTrue(page.contains("MaterialTheme.colorScheme.surfaceBright"))
        assertTrue(page.contains("verticalScroll(rememberScrollState())"))
        assertTrue(destination.contains("HOOK_CHAIN_INTERFACE"))
        assertTrue(destination.contains("HOOK_CHAIN_FONT"))
        assertTrue(destination.contains("TYPEFACE"))
        assertTrue(destination.contains("isChildPage()"))
        assertTrue(appEditor.contains("state.actions.navigate("))
        assertTrue(appEditor.contains("ConfigEditorDestination.TYPEFACE"))
        assertFalse(appEditor.contains("hookChainEditorVisible"))
        assertTrue(appWorkspace.contains("ConfigEditorAnimatedContent("))
        assertTrue(appWorkspace.contains(
                "bottomPadding = padding.calculateBottomPadding()"))
        assertTrue(coordinator.contains("ConfigEditorAnimatedContent("))
        assertTrue(coordinator.contains("animateSize = false"))
        assertTrue(coordinator.contains("clipContentToAnimatedBounds = false"))
        assertTrue(coordinator.contains(
                "editorState.destination == ConfigEditorDestination.MAIN"))
        val appOverlay = read(
                "src/main/java/com/dpis/module/appconfig/presentation/AppConfigEditorOverlay.kt")
        assertTrue(appOverlay.contains("onReturnToMain"))
        assertTrue(appOverlay.contains("bottomSheetState.partialExpand()"))
        assertTrue(viewModel.contains("var editingDestination: ConfigEditorDestination"))
        val startup = read(
            "src/main/java/com/dpis/module/ui/presentation/MainStartupSession.kt"
        )
        assertTrue(startup.contains("viewModel?.editingDestination"))
        assertTrue(startup.contains("retained.editingDestination"))
        assertTrue(templates.contains("val editorDestination = state.editorDestination"))
        assertTrue(templatePresentation.contains(
                "val editorDestination: ConfigEditorDestination"))
        assertTrue(startup.contains("retained.workspaceSessionState"))
        assertTrue(templatePresentation.contains("val editorDestination: ConfigEditorDestination"))
        assertTrue(startup.contains("ensureWorkspaceSession().saveState(outState)"))
        assertTrue(templates.contains("HookChainEditorPage("))
        assertTrue(templates.contains("AppTypefacePickerPage("))
        assertTrue(templates.contains("destination = editorDestination"))
        assertTrue(templates.contains(
                "bottomSafePadding = padding.calculateBottomPadding()"))
        assertFalse(templates.contains("hookChainDialogVisible"))
        assertFalse(File(
                "src/main/java/com/dpis/module/ui/compose/AppHookChainEditorDialog.kt").exists())
    }

    @Test
    fun wechatEditorRowUsesTheSameVerticalRhythmAsValueModeRows() {
        val editor = read(
                "src/main/java/com/dpis/module/appconfig/presentation/AppConfigEditorContent.kt")

        val wechatStart = editor.indexOf("if (state.showsWechatDpi())")
        val wechatEnd = editor.indexOf(
                "Spacer(Modifier.height(AppConfigSheetUiTokens.ControlGroupGap))", wechatStart)
        assertTrue(wechatStart > 0)
        assertTrue(wechatEnd > wechatStart)

        val wechatRow = editor.substring(wechatStart, wechatEnd)
        assertTrue(wechatRow.contains(
                ".height(AppConfigSheetUiTokens.FieldTopInset + rememberEditorControlHeight())"))
        assertTrue(wechatRow.contains("verticalAlignment = Alignment.Bottom"))
        assertTrue(wechatRow.contains("state.actions.showWechatDpiHelp()"))
        assertFalse(wechatRow.contains("EditorInputError"))
    }

    @Test
    fun searchPagesDismissInputWhenTheirNonInputContentIsTouched() {
        val controls = read(
                "src/main/java/com/dpis/module/ui/presentation/editor/EditorControls.kt")
        val apps = read(
                "src/main/java/com/dpis/module/applist/presentation/AppListContent.kt")
        val targets = read(
                "src/main/java/com/dpis/module/templates/presentation/QuickTemplateTargetsContent.kt")
        val templates = read(
                "src/main/java/com/dpis/module/templates/presentation/TemplateWorkspaceList.kt")

        assertTrue(controls.contains("fun Modifier.clearTextInputFocusOnPointerDown("))
        assertTrue(controls.contains("focusManager.clearFocus(force = true)"))
        assertTrue(controls.contains("fun Modifier.clearTextInputFocusOutside("))
        assertTrue(controls.contains("fun Modifier.clearTextInputFocusWhenImeDismissed("))
        assertTrue(apps.contains(".clearTextInputFocusOnPointerDown(inputFocusManager)"))
        assertTrue(targets.contains(".clearTextInputFocusOutside(focusManager, inputFocusBoundary)"))
        assertTrue(targets.contains("target-search"))
        assertTrue(templates.contains(".clearTextInputFocusOnPointerDown(focusManager)"))
        val search = read(
            "src/main/java/com/dpis/module/ui/presentation/workspace/WorkspaceSearchCard.kt"
        )
        assertTrue(search.contains(".textInputFocusBehavior()"))
        assertTrue(targets.contains(".textInputFocusBehavior()"))
    }

    private fun read(relativePath: String): String {
        return String(
                Files.readAllBytes(File(relativePath).toPath()),
                StandardCharsets.UTF_8
        )
    }
}
