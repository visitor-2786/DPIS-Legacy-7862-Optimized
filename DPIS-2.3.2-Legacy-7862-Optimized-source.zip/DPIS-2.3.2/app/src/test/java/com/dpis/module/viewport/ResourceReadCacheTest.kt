package com.dpis.module.viewport

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ResourceReadCacheTest {
    private data class ConfigurationState(
        var density: Int = 320,
        var width: Int = 450,
        var font: Float = 1f,
        var locale: String = "ko",
        var night: Boolean = false,
        var window: Int = 0,
    )

    @Test
    fun repeatedReadsDoNotCopyOrExtendTheRefreshDeadline() {
        var copies = 0
        val cache = ResourceReadCache<ConfigurationState>(250L) { copies++; it.copy() }
        val scope = Any()
        val store = Any()
        val output = ConfigurationState()
        cache.remember(scope, "map", store, output, 1, 100L)
        repeat(10_000) {
            assertTrue(cache.matches(scope, "map", store, output, 1, 349L))
        }
        assertTrue(copies == 1)
        assertFalse(cache.matches(scope, "map", store, output, 1, 350L))
    }

    @Test
    fun externalMutationCannotMutateTheRememberedSnapshot() {
        val cache = ResourceReadCache<ConfigurationState>(250L) { it.copy() }
        val scope = Any()
        val store = Any()
        val output = ConfigurationState()
        cache.remember(scope, "map", store, output, 1, 100L)
        output.width = 451
        assertFalse(cache.matches(scope, "map", store, output, 1, 101L))
        assertTrue(cache.matches(scope, "map", store, ConfigurationState(), 1, 101L))
    }

    @Test
    fun ownerStoreGenerationAndResourceScopeCannotCrossReuse() {
        val cache = ResourceReadCache<ConfigurationState>(250L) { it.copy() }
        val scope = Any()
        val store = Any()
        val output = ConfigurationState()
        cache.remember(scope, "map", store, output, 1, 100L)
        assertFalse(cache.matches(Any(), "map", store, output, 1, 101L))
        assertFalse(cache.matches(scope, "other", store, output, 1, 101L))
        assertFalse(cache.matches(scope, "map", Any(), output, 1, 101L))
        assertFalse(cache.matches(scope, "map", store, output, 2, 101L))
        assertFalse(cache.matches(null, "map", store, output, 1, 101L))
        assertFalse(cache.matches(scope, "map", store, output, 1, 99L))
    }

    @Test
    fun nonDensityConfigurationChangesAlsoInvalidateTheRead() {
        val cache = ResourceReadCache<ConfigurationState>(250L) { it.copy() }
        val scope = Any()
        val store = Any()
        val output = ConfigurationState()
        cache.remember(scope, "map", store, output, 1, 100L)
        for (changed in listOf(
            output.copy(density = 321), output.copy(width = 451),
            output.copy(font = 1.1f), output.copy(locale = "en"),
            output.copy(night = true), output.copy(window = 1),
        )) {
            assertFalse(cache.matches(scope, "map", store, changed, 1, 101L))
        }
    }
}
