package com.dpis.module;

import com.dpis.module.fonts.FontApplyMode;

import com.dpis.module.runtime.font.CompatFontPropertySyncer;
import com.dpis.module.runtime.font.HyperOsNativeFontPropertySyncer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import java.util.LinkedHashSet;
import java.util.Set;
import com.dpis.module.config.DpisConfigStore;

public class HyperOsNativeFontPropertySyncerTest {
    @Test
    public void shellQuoteEscapesSingleQuotes() {
        assertEquals("'debug.dpis.forcefont.a55b5fe1'",
                HyperOsNativeFontPropertySyncer.shellQuoteForTest("debug.dpis.forcefont.a55b5fe1"));
        assertEquals("'a'\\''b'", HyperOsNativeFontPropertySyncer.shellQuoteForTest("a'b"));
        assertEquals("''", HyperOsNativeFontPropertySyncer.shellQuoteForTest(""));
    }
    @Test
    public void buildPublishCommandSetsForceFontPropertyOnly() {
        assertEquals("setprop 'debug.dpis.forcefont.a55b5fe1' '300'",
                HyperOsNativeFontPropertySyncer.buildPublishCommandForTest(
                        "debug.dpis.forcefont.a55b5fe1", 300));
    }

    @Test
    public void compatFontCommandUsesSeparateProperty() {
        assertEquals("setprop 'debug.dpis.compatfont.a55b5fe1' '200'",
                CompatFontPropertySyncer.buildSetCommandForTest(
                        "debug.dpis.compatfont.a55b5fe1", 200));
    }

    @Test
    public void preservesCompatForceFontForActiveFieldRewriteTarget() {
        FakePrefs preferences = new FakePrefs();
        preferences.edit()
                .putStringSet(DpisConfigStore.KEY_TARGET_PACKAGES,
                        new LinkedHashSet<>(Set.of("com.miui.gallery")))
                .putInt("font.com.miui.gallery.scale_percent", 200)
                .putString("font.com.miui.gallery.mode", FontApplyMode.FIELD_REWRITE)
                .commit();
        DpisConfigStore store = new DpisConfigStore(preferences);

        assertTrue(HyperOsNativeFontPropertySyncer.shouldPreserveCompatForceFontForTest(
                store, "com.miui.gallery"));
    }

    @Test
    public void doesNotPreserveCompatForceFontForSystemEmulationOrDisabledTarget() {
        FakePrefs systemEmulation = new FakePrefs();
        systemEmulation.edit()
                .putStringSet(DpisConfigStore.KEY_TARGET_PACKAGES,
                        new LinkedHashSet<>(Set.of("com.miui.gallery")))
                .putInt("font.com.miui.gallery.scale_percent", 200)
                .putString("font.com.miui.gallery.mode", FontApplyMode.SYSTEM_EMULATION)
                .commit();
        assertFalse(HyperOsNativeFontPropertySyncer.shouldPreserveCompatForceFontForTest(
                new DpisConfigStore(systemEmulation), "com.miui.gallery"));

        FakePrefs disabled = new FakePrefs();
        disabled.edit()
                .putStringSet(DpisConfigStore.KEY_TARGET_PACKAGES,
                        new LinkedHashSet<>(Set.of("com.miui.gallery")))
                .putInt("font.com.miui.gallery.scale_percent", 200)
                .putString("font.com.miui.gallery.mode", FontApplyMode.FIELD_REWRITE)
                .putBoolean("target.com.miui.gallery.dpis_enabled", false)
                .commit();
        assertFalse(HyperOsNativeFontPropertySyncer.shouldPreserveCompatForceFontForTest(
                new DpisConfigStore(disabled), "com.miui.gallery"));
    }

    @Test
    public void recoveryPublishesFieldRewriteWithoutNativeHookGate() {
        FakePrefs preferences = new FakePrefs();
        preferences.edit()
                .putBoolean("font.hyperos_flutter_hook_enabled", false)
                .commit();
        DpisConfigStore store = new DpisConfigStore(preferences);

        assertTrue(HyperOsNativeFontPropertySyncer.shouldPublishForceFontOnRecoveryForTest(
                store, "com.miui.gallery", FontApplyMode.FIELD_REWRITE));
        assertFalse(HyperOsNativeFontPropertySyncer.shouldPublishForceFontOnRecoveryForTest(
                store, "com.miui.gallery", FontApplyMode.OFF));
        assertFalse(HyperOsNativeFontPropertySyncer.shouldPublishForceFontOnRecoveryForTest(
                store, "com.example.app", FontApplyMode.SYSTEM_EMULATION));
        assertTrue(HyperOsNativeFontPropertySyncer.shouldPublishForceFontOnRecoveryForTest(
                store, "com.miui.gallery", FontApplyMode.SYSTEM_EMULATION));
    }
}
