package com.dpis.module;

import com.dpis.module.fonts.FontApplyMode;

import com.dpis.module.runtime.font.PaintTextSizeFallbackHookInstaller;

import org.junit.Test;

import static org.junit.Assert.assertEquals;
import com.dpis.module.config.DpisConfigStore;

public class PaintTextSizeFallbackHookInstallerTest {
    @Test
    public void returnsFactorForFieldRewriteMode() {
        FakePrefs prefs = new FakePrefs();
        DpisConfigStore store = new DpisConfigStore(prefs);
        store.setTargetFontScalePercent("com.max.xiaoheihe", 150);
        store.setTargetFontApplyMode("com.max.xiaoheihe", FontApplyMode.FIELD_REWRITE);

        float factor = PaintTextSizeFallbackHookInstaller.resolveFieldRewriteFactor(
                store, "com.max.xiaoheihe");

        assertEquals(1.5f, factor, 0.0001f);
    }

    @Test
    public void returnsIdentityFactorForSystemEmulationMode() {
        FakePrefs prefs = new FakePrefs();
        DpisConfigStore store = new DpisConfigStore(prefs);
        store.setTargetFontScalePercent("com.max.xiaoheihe", 150);
        store.setTargetFontApplyMode("com.max.xiaoheihe", FontApplyMode.SYSTEM_EMULATION);

        float factor = PaintTextSizeFallbackHookInstaller.resolveFieldRewriteFactor(
                store, "com.max.xiaoheihe");

        assertEquals(1.0f, factor, 0.0001f);
    }
}
